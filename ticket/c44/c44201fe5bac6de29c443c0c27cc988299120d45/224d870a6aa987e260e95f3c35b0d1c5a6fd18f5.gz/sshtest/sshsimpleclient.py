#!/usr/bin/env python

import sys
sys.path.insert(0, '/home/jason/src/Twisted/')

from twisted.conch.ssh import transport, userauth, connection, common, keys, channel
from twisted.internet import defer, protocol, reactor
from twisted.python import log
import struct, getpass, os

USER = os.getlogin()
HOST = sys.argv[1] 
PASSPHRASE = '12345'

PRIVATE_KEY = """-----BEGIN DSA PRIVATE KEY-----
Proc-Type: 4,ENCRYPTED
DEK-Info: DES-EDE3-CBC,4B33DB591CCE2582

yB46SeeAb8Jz1v5UwgYPMoLakfOsrfbEi4rwbvpvvPDocr2UccNBVtI5wjGjbprT
ga9HaLXorvdcxxWk2naWLECngaxOQm5zmyQ2s5bVpJJqWZgmeo1i6el+V8YVxnuO
tVhRx+RGc5xxyKGEMpxxhy4ZGSY8QZZvZ5mBglNS3Moc+hSIfkd9sMG/Qtr+/t18
b2L/EEJf2Cba9A8G4RbPNM72/CQMHIlzVUYmaWugzXgRCF9E6UoRI0YyE0o7VQl9
LYg/lKJaPhzekromMRFpYwQPiKzw34sUXiwBvGk/WyDxmTm7GgKqM7AcWsBOYBpV
GbS3pxRiwuPGh4bS113Dijh18CikH/+yGID6OEFaeOp2mmIWf0tAy+Y85cD8IGZZ
r+jdZZyCtOWiHUe1qvmFg75LiajU0fDV6uFPIv+nQ+XqksHm69mdl3q7eDz77Feg
mxnFMZ/xmuEZLV8JCGPRp6slHBy8pYbfgVibmdtlkH5LN+vmL51h3wAkussf+8ne
OiFG5ENZMBguD3IzFuOpjabxPiUwpLAeblSy/xlgdSRT6vkZboXhg+ZEW2BkgAtw
YLmrGMztflZvYWERCudEsQ==
-----END DSA PRIVATE KEY-----
"""

PUBLIC_KEY = """ssh-dss AAAAB3NzaC1kc3MAAACBAPB3J9EOq0mv7vONJaOsFlkV6NkUIZxnWjJYUW/P5t4INITesCD/+epPWE9JeV4izJADnR2mm0vJsb2hQgmHktTBzCE3BOAGwPZIR9gphKJYp/gIixcr2bjFHbcEzekMa7R5kbKWAQHy/58R9Ur2hFyFwnumHHi+3RX/752I7qtlAAAAFQCUHa+VAw62/zLDqqWTaFRZSAzGowAAAIEArMuh+lgMELSqX1hfdvve9d+LbF2ssJa+eVmxZK3cZ8GCJrl5ersJ0OH5G1Nq5nead+wq4XPtKk8rzRYKO5QHUogi5RgMPCLnXp3jmGtZ0ddLmf7y9xKLIutp5MQzdHjwJxuQve0ZRqNfnAR39w0Ue9Ym37FXDTKs+IdtoNfzTKoAAACAQWhJ1EZoICVkLIl1uOBpzFRKn1YxIySBuaYZNHCzOOWfxWjHwJfHDk70t664iNJe3OQIpq3+uTsoWsLuzwu6C2XS0BHYudTir7mA1R7m+b4vDid06CYJEhnwk+b1OlIPimxvlRmiO0B24OqaTmY7b2bzuJpkCEBvHUV+zm/vowk= """

class SimpleTransport(transport.SSHClientTransport):
    def verifyHostKey(self, hostKey, fingerprint):
        print 'host key fingerprint: %s' % fingerprint
        return defer.succeed(1) 

    def connectionSecure(self):
        self.requestService(
            SimpleUserAuth(USER,
                SimpleConnection()))

            
class SimpleUserAuth(userauth.SSHUserAuthClient):
    
    #def getPassword(self):
    #    return defer.succeed(getpass.getpass("%s@%s's password: " % (USER, HOST)))

    def getPublicKey(self):
        if hasattr(self, 'lastPublicKey'):
            # the file doesn't exist, or we've tried a public key
            return
        return keys.getPublicKeyString(data=PUBLIC_KEY)

    def getPrivateKey(self):
        return defer.succeed(keys.getPrivateKeyObject(data=PRIVATE_KEY, passphrase=PASSPHRASE))

class SimpleConnection(connection.SSHConnection):
    def serviceStarted(self):
        self.openChannel(TrueChannel(2**16, 2**15, self))
        self.openChannel(FalseChannel(2**16, 2**15, self))
        self.openChannel(CatChannel(2**16, 2**15, self))

class TrueChannel(channel.SSHChannel):
    name = 'session' # needed for commands

    def openFailed(self, reason):
        print 'true failed', reason
    
    def channelOpen(self, ignoredData):
        self.conn.sendRequest(self, 'exec', common.NS('true'))

    def request_exit_status(self, data):
        status = struct.unpack('>L', data)[0]
        print 'true status was: %s' % status
        self.loseConnection()

class FalseChannel(channel.SSHChannel):
    name = 'session'

    def openFailed(self, reason):
        print 'false failed', reason

    def channelOpen(self, ignoredData):
        self.conn.sendRequest(self, 'exec', common.NS('false'))

    def request_exit_status(self, data):
        status = struct.unpack('>L', data)[0]
        print 'false status was: %s' % status
        self.loseConnection()

class CatChannel(channel.SSHChannel):
    name = 'session'

    def openFailed(self, reason):
        print 'echo failed', reason

    def channelOpen(self, ignoredData):
        self.data = ''
        d = self.conn.sendRequest(self, 'exec', common.NS('cat'), wantReply = 1)
        d.addCallback(self._cbRequest)

    def _cbRequest(self, ignored):
        self.write('hello conch\n')
        self.conn.sendEOF(self)

    def dataReceived(self, data):
        self.data += data

    def closed(self):
        print 'got data from cat: %s' % repr(self.data)
        self.loseConnection()
        reactor.stop()


logFile = open("log", "w+b")
log.startLogging(logFile)

protocol.ClientCreator(reactor, SimpleTransport).connectTCP(HOST, 22)
reactor.run()
