#!/usr/bin/python

import optparse
import kerberos
import sys
import httplib

def sendRequest(host, port, ssl, method, uri, headers):
    response = None
    if ssl:
        http = httplib.HTTPSConnection(host, port)
    else:
        http = httplib.HTTPConnection(host, port)
    try:
        #http.set_debuglevel(10)
        http.request(method, uri, "", headers)
        response = http.getresponse()
        data = response.read()
    finally:
        http.close()
    
    return response, data

def nego_val(response, emptyOk=False):
    hdrs = response.msg.getheaders("www-authenticate")
    nego = None
    for h in hdrs:
        if ' ' in h:
            kind, val = h.split(' ', 1)
        else:
            kind, val = h, ''

        kind = kind.lower()

        if kind=='negotiate':
            nego = val
            break
    else:
        if emptyOk:
            return None
        else:
            raise Exception("No www-authenticate header in initial HTTP response.")

    return nego

def main():
    parser = optparse.OptionParser()
    parser.add_option('-H', '--host', dest='host', action='store', type='string')
    parser.add_option('-p', '--port', dest='port', action='store', type='int', default=80)
    parser.add_option('-s', '--ssl', dest='ssl', action='store_true', default=False)
    parser.add_option('-u', '--url', dest='url', action='store', type='string', default='/')
    parser.add_option('-P', '--principal', dest='princ', action='store', type='string', default='')

    (config, args) = parser.parse_args()

    if config.princ:
        principal = config.princ
    else:
        principal = 'HTTP@'+config.host

    headers = {}

    rc, vc = kerberos.authGSSClientInit(principal)

    while True:
        # Initial request without auth header
        response, data = sendRequest(config.host, config.port, config.ssl, "GET", config.url, headers)

        if response is None:
            raise Exception("HTTP request to server failed")

        st = response.status
        if st>=200 and st<=399:
            # ok!
            break

        if st!=401:
            raise Exception("Response code is neither success nor 401: %s" % (st,))

        val = nego_val(response)

        # feed to the gssapi
        kerberos.authGSSClientStep(vc, val);

        headers["Authorization"] = "negotiate %s" % kerberos.authGSSClientResponse(vc)    

    # final resp should have code too
    val = nego_val(response, emptyOk=True)
    if val:
        kerberos.authGSSClientStep(vc, val)

    # fixme: how do we know auth was successful?
    rc = kerberos.authGSSClientClean(vc);

    print response.status, response.reason
    print response.msg

    print data


if __name__=='__main__':
    main()
