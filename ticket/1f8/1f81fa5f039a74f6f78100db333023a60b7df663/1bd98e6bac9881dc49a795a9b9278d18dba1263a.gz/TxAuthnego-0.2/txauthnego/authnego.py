
from zope.interface import implements, Attribute

from twisted.cred import credentials, checkers
from twisted.web.iweb import ICredentialFactory
from twisted.python import log

import kerberos

class INegotiateCredentials(credentials.ICredentials):
    challenge = Attribute('the spnego ticket')

class NegotiateCredentials:
    """
    Very simple wrapper around the "Authorization: Negotiate blob" and the
    originating request (so we can send back the final blob)
    """
    implements(INegotiateCredentials)

    def __init__(self, challenge, request):
        self.challenge = challenge
        self.request = request

class NegotiateChecker:
    implements(checkers.ICredentialsChecker)

    credentialInterfaces = (INegotiateCredentials,)

    def __init__(self, servicePrincipal, stripRealm=False):
        """
        This checks Negotiate auth credentials. At the moment, only kerberos
        is supported.

        @type servicePrincipal: C{str}
        @param servicePrincipal: the name of the service principal to extract
            from the keytab. In the case of multiple virtual hosts, you might
            want to subclass me, and extract this on-the-fly from the request.

        @type stripRealm: C{bool}
        @param stripRealm: should I turn user@REALM into user - THIS IS DANGEROUS
            if you have any cross-realm trusts or similar, so it defaults to False.

        """
        self.servicePrincipal = servicePrincipal
        self.stripRealm = stripRealm

    def requestAvatarId(self, credentials):
        # FIXME: this function makes several assumptions which might not be valid
        #
        # 1. that the negotiate auth is Kerberos :o)
        #    I don't have a pluggable gss library to test against...
        # 2. that the auth will succeed in a single round trip
        #    I think this is true for kerberos
        # 3. that the kerberos libraries don't block on the server-side
        #    Again I think this is true for kerberos

        username = None

        rv, context = kerberos.authGSSServerInit(self.servicePrincipal)
        try:
            kerberos.authGSSServerStep(context, credentials.challenge)

            resp = kerberos.authGSSServerResponse(context)
            if resp:
                # the server might have one final blob to send the client e.g. the
                # response to the client challenge in mutual auth. We have stashed
                # the "request" away in the credentials so we can send a reply header
                # which is a bit odd, but I can't think of a better way to do it.
                credentials.request.setHeader('WWW-Authenticate', 'Negotiate '+resp)

            username = kerberos.authGSSServerUserName(context)
            if self.stripRealm:
                # FIXME: can @ appear anywhere else?
                username = username.split('@')[0]

        finally:
            kerberos.authGSSServerClean(context)

        return username

class NegotiateCredentialFactory(object):
    """
    Credential Factory for HTTP Negotiate (RFC 4559) Authentication
    """

    implements(ICredentialFactory)

    scheme = 'negotiate'

    def getChallenge(self, request):
        return dict()

    def decode(self, response, request):
        return NegotiateCredentials(response, request)
