
from zope.interface import implements, Attribute

from twisted.cred import credentials, checkers
from twisted.web.iweb import ICredentialFactory
from twisted.python import log

import kerberos

class IKerberosCredentials(credentials.ICredentials):
    challenge = Attribute('the spnego ticket')

class KerberosCredentials:
    implements(IKerberosCredentials)

    def __init__(self, challenge, request):
        self.challenge = challenge
        self.request = request

class KerberosChecker:
    implements(checkers.ICredentialsChecker)

    credentialInterfaces = (IKerberosCredentials,)

    def __init__(self, servicePrincipal, stripRealm=False):
        self.servicePrincipal = servicePrincipal
        self.stripRealm = stripRealm

    def requestAvatarId(self, credentials):
        # FIXME: this entire function assumes that kerberos auth will
        # succeed in a single step, which is not always the case. Given
        # the current Twisted interface, I don't know how to handle that.

        username = None

        log.msg('creating context', self.servicePrincipal)

        rv, context = kerberos.authGSSServerInit(self.servicePrincipal)
        try:
            kerberos.authGSSServerStep(context, credentials.challenge)

            resp = kerberos.authGSSServerResponse(context)
            if resp:
                # this is a bit odd; we might send a value to the client
                # in a www-authenticate header even if we are done e.g.
                # for mutual auth. Is this ok?
                credentials.request.setHeader('WWW-Authenticate', 'Negotiate '+resp)

            username = kerberos.authGSSServerUserName(context)
            if self.stripRealm:
                # FIXME: can @ appear anywhere else?
                username = username.split('@')[0]

        finally:
            kerberos.authGSSServerClean(context)

        return username

class KerbCredentialFactory(object):
    """
    Credential Factory for HTTP Negotiate (RFC 4559) Authentication
    """

    implements(ICredentialFactory)

    scheme = 'negotiate'

    def getChallenge(self, request):
        # no arguments
        return dict()

    def decode(self, response, request):
        print "making kerb creds from", response, request
        return KerberosCredentials(response, request)
