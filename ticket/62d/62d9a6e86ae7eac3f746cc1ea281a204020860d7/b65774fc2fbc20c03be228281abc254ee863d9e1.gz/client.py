#!/usr/bin/python

from dryad.client.twistedclient import DryadTwistedClient

client = None

def connected(_client):
    global client
    client = _client
    client.lengthTestShort().addCallback(cbResponse)

def cbResponse(data):
    print data, 'short'
    client.lengthTestLong().addCallback(cbLongResponse)

def cbLongResponse(data):
    print data, 'long'

DryadTwistedClient(callback=connected)