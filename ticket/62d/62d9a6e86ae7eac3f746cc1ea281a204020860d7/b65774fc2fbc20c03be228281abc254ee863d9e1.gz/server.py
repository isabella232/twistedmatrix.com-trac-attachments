#!/usr/bin/python

from dryad import main
main.startCore()
