# -*- coding: utf-8 -*- 
# dryad/core/json.py
#
# Copyright (C) 2008 Damien Churchill <damoxc@gmail.com>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.    See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.    If not, write to:
# 	The Free Software Foundation, Inc.,
# 	51 Franklin Street, Fifth Floor
# 	Boston, MA    02110-1301, USA.
#
#    In addition, as a special exception, the copyright holders give
#    permission to link the code of portions of this program with the OpenSSL
#    library.
#    You must obey the GNU General Public License in all respects for all of
#    the code used other than OpenSSL. If you modify file(s) with this
#    exception, you may extend this exception to your version of the file(s),
#    but you are not obligated to do so. If you do not wish to do so, delete
#    this exception statement from your version. If you delete this exception
#    statement from all source files in the program, then also delete it here.

import logging

from time import time
from simplejson import loads, dumps
from twisted.internet.protocol import Protocol
from twisted.conch.ssh.session import SSHSessionProcessProtocol
from dryad import __version__

log = logging.getLogger(__name__)

class DryadJsonProtocol(Protocol):
    def __init__(self, user, core, json):
        self.user = user
        self.core = core
        self.json = json
        self.loadCommands()

    def loadCommands(self):
        methods = filter(lambda funcname: funcname.startswith('export_'), 
                         dir(self))
        self.commands = [cmd.replace('export_', '', 1) for cmd in methods]

    def connectionMade(self):
        Protocol.connectionMade(self)
        self.handleRequest(loads(self.json))

    def handleRequest(self, request):
        if not request.has_key('method'):
            return

        method = request['method']
        if request.has_key('params'):
            params = request['params']
        else:
            params = []

        error = None
        try:
            if method.startswith('system'):
                result = self._execSystem(method, params)
            elif method.startswith('_'):
                raise Exception('Methods starting with _ are illegal')
            else:
                result = self._exec(method, params)

        except Exception, e:
            log.exception(e)
            result = None
            error = str(e)

        response = dumps({
            'version': '1.1',
            'result': result,
            'error': error,
            'id': request['id']
        })
        log.debug('response: %s' % response)
        self.transport.write(response)

    def _execSystem(self, method, params):
        if method == 'systemListMethods':
            return self.commands
        raise Exception('Unknown method')

    def _exec(self, method, params):
        if method in self.commands:
            if hasattr(self, 'export_' + method):
                return getattr(self, 'export_' + method)(*params)

            parts = method.split('_', 1)
            pluginName = parts[0]
            method = parts[1]
            if self.core.pluginmanager.plugins.has_key(pluginName):
                plugin = self.core.pluginmanager.plugins[pluginName]
                return plugin.execute(method, *params)
        raise Exception('Unknown method')

    def connectionLost(self, reason):
        log.debug('Disconnect: %s', reason)

    def export_getStatus(self):
        names = [str(plugin) for plugin in self.core.pluginmanager.plugins]
        return {
            'dryadVersion': __version__,
            'loadedPlugins': names,
            'time': time()
        }

    def export_lengthTestShort(self):
        return 'a' * 20000
    
    def export_lengthTestLong(self):
        return 'a' * 100000