# -*- coding: utf-8 -*- 
# dryad/core/auth.py
#
# Copyright (C) 2008 Damien Churchill <damoxc@gmail.com>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.    See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.    If not, write to:
# 	The Free Software Foundation, Inc.,
# 	51 Franklin Street, Fifth Floor
# 	Boston, MA    02110-1301, USA.
#
#    In addition, as a special exception, the copyright holders give
#    permission to link the code of portions of this program with the OpenSSL
#    library.
#    You must obey the GNU General Public License in all respects for all of
#    the code used other than OpenSSL. If you modify file(s) with this
#    exception, you may extend this exception to your version of the file(s),
#    but you are not obligated to do so. If you do not wish to do so, delete
#    this exception statement from your version. If you delete this exception
#    statement from all source files in the program, then also delete it here.

from twisted.cred import credentials, portal
from twisted.conch import checkers, error
from twisted.conch.ssh import keys, factory
from twisted.python import failure
from zope.interface import implements

import os
import base64
import logging

log = logging.getLogger(__name__)

keyText = "ssh-rsa AAAAB3NzaC1yc2EAAAABIwAAAQEAz1/O6F0n7+qaES6N7KeBDhrT0MHIB3" \
	"30MRdkZNvYq201c5DHYODFU8xrv7aR4EA30ySodu2x3w87tZ4DvaYKCGCMquY5PXfYiBFBhF" \
	"YepvW82ZJPqx6NnpMZm59ug9D5XpfMgnIGjXozcyL7K09OkANgIMkEDX7ZHCBphN/uT/hZp6" \
	"woGB8Y6mcBtiXOj4DiylMMPmz/QE8/2/Or07IWkaWm6sD1lWoSFQoiCXVrEiPF+1fmRgJUJw" \
	"vohScyV0CZPPOgxjSq3yqnhMK6TEzY3Tg4mFEnn0vuma1EghT44k4a7VdmE39duGSAKPZdla" \
	"7ht4ErdYJh2Hmv/2A/RxMJEQ=="

class DryadCredentialsChecker(object):
	implements(checkers.ICredentialsChecker)
	credentialInterfaces = (credentials.ISSHPrivateKey,)
	
	def __init__(self):
		self.loadKeys()
		if len(self.authorizedKeys) == 0:
			log.warn('No authorised keys setup')
		
	def loadKeys(self):
		self.authorizedKeys = {
			'test': keys.Key.fromString(keyText)
		}
	
	def requestAvatarId(self, credentials):
		log.info('%s attempting to auth' % credentials.username)
		return credentials.username
		if self.authorizedKeys.has_key(credentials.username):
			userKey = self.authorizedKeys[credentials.username]
			if not credentials.blob == userKey.blob():
				log.info('Invalid key')
				raise failure.Failure(
					error.ConchError("I don't recognize that key"))
			
			if not credentials.signature:
				log.warn('Not a valid public key')
				return failure.Failure(error.ValidPublicKey())
			
			pubKey = keys.Key.fromString(data=credentials.blob)
			if pubKey.verify(credentials.signature, credentials.sigData):
				log.info('Authenticated successfully')
				return credentials.username
			else:
				log.info('Incorrect signature')
				return failure.Failure(
					error.ConchError("Incorrect signature"))
		else:
			log.info('No such user')
			return failure.Failure(error.ConchError("No such user"))
