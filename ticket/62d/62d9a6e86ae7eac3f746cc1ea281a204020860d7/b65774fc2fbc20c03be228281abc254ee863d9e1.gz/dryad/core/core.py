# -*- coding: utf-8 -*- 
# dryad/core/core.py
#
# Copyright (C) 2008 Damien Churchill <damoxc@gmail.com>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.    See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.    If not, write to:
# 	The Free Software Foundation, Inc.,
# 	51 Franklin Street, Fifth Floor
# 	Boston, MA    02110-1301, USA.
#
#    In addition, as a special exception, the copyright holders give
#    permission to link the code of portions of this program with the OpenSSL
#    library.
#    You must obey the GNU General Public License in all respects for all of
#    the code used other than OpenSSL. If you modify file(s) with this
#    exception, you may extend this exception to your version of the file(s),
#    but you are not obligated to do so. If you do not wish to do so, delete
#    this exception statement from your version. If you delete this exception
#    statement from all source files in the program, then also delete it here.

import os
import sys
import base64
import logging
from time import time

from twisted.cred import checkers, credentials, portal
from twisted.conch import error, avatar, recvline, interfaces as conchinterfaces
from twisted.conch.ssh import factory, userauth, connection, keys, session
from twisted.conch.insults import insults
from twisted.application import service, internet
from twisted.internet import reactor, protocol, defer
from twisted.python import failure, randbytes
from zope.interface import implements

from dryad import __version__
from dryad.core.auth import DryadCredentialsChecker
from dryad.core.json import DryadJsonProtocol

log = logging.getLogger(__name__)

privateKeyText = """-----BEGIN RSA PRIVATE KEY-----
MIICWwIBAAKBgQC+/BIKz8Yb9RT+BJh2HzypfNVZzLhLxvNIzij6jDIP2vbzQgai
UzyI8zxAei876j447puupVM1283ZNLsanUqIGUvYOkqN2KG17Puzl2t9CUPhbQZi
YNutuUf4wuu4yIcFsKBnYnf022schxgaqauDsiNQNIJzQCM5BUvYfu8MxQIDAQAB
AoGAYFVDQILXGckAYrSstoBBF/iooRgbKdXbZzDeCKrooYjAIal/MSetFCMklB1N
b/pSkmMA0hIAK92IMnRfoCgQrECBjeFcdrNuDOuIuZzTTQewPI9EoHNp9WPOoaAP
385n4TdCfRP3LtZs6/Z6/8eI9VjrL/Utm/08MyF73tSDByECQQDhq0SjPMb6XkI3
o0NsaJuGrO5sCPISYPnHwbxNg05gGLAhT3OE/GFpZsGaKM4nZwDDmM19zi+o+3o0
i78nY92ZAkEA2Kdla3eACmRQzvlItv0DDOIsqcvupSYzINVg57tLi42plVP4YGN+
Nryt+px+8VRHkNMJNk0KUMhBreq+bgqsDQJAVL6/aNmzE2SAU2qBMF3cQegBJRr6
5QH76xMLBsTPkvDSe7/dbsxkPHO1MpIuUMeylsF0MdFTPo8ppj/wifdLyQJAVHGq
jiCdv28qMAHp3ajwL21YizX5ZlVlSD7i7m+KGnK0zodUH/2njB4ukae9ssJuwnv+
8zND+giT0P3WC34NYQJAVUsPQqOKckK4rih8Z8VxYddABE1XJ6v+92dE22xVYQO/
OI+HMCJa/Hfc6Qh0QF3+28+2RCOBc+w5iez9rRe8SA==
-----END RSA PRIVATE KEY-----"""

publicKeyText = "ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAAAgQC+/BIKz8Yb9RT+BJh2Hzyp" \
			  "fNVZzLhLxvNIzij6jDIP2vbzQgaiUzyI8zxAei876j447puupVM1283ZNLsanU" \
			  "qIGUvYOkqN2KG17Puzl2t9CUPhbQZiYNutuUf4wuu4yIcFsKBnYnf022schxga" \
			  "qauDsiNQNIJzQCM5BUvYfu8MxQ=="

class DryadAvatar(avatar.ConchUser):
	implements(conchinterfaces.ISession)
	
	def __init__(self, username, core):
		avatar.ConchUser.__init__(self)
		self.username = username
		self.core = core
		self.channelLookup.update({'session': session.SSHSession})
	
	def openShell(self, protocol):
		log.info('Shell request by %s' % self.username)
		serverProtocol = insults.ServerProtocol(DryadShellProtocol, self, self.core)
		serverProtocol.makeConnection(protocol)
		protocol.makeConnection(session.wrapProtocol(serverProtocol))
		protocol.core = self.core
	
	def getPty(self, terminal, windowSize, attrs):
		return None
	
	def execCommand(self, protocol, cmd):
		log.info('JSON request by %s' % self.username)
		log.debug('request: %s' % cmd)
		serverProtocol = DryadJsonProtocol(self, self.core, cmd)
		serverProtocol.makeConnection(protocol)
		protocol.makeConnection(session.wrapProtocol(serverProtocol))
	
	def eofReceived(self):
		pass
	
	def closed(self):
		pass

class DryadRealm:
	implements(portal.IRealm)
	
	def __init__(self, core):
		self.core = core
	
	def requestAvatar(self, avatarId, mind, *interfaces):
		if conchinterfaces.IConchUser in interfaces:
			return interfaces[0], DryadAvatar(avatarId, self.core), lambda: None
		else:
			raise Exception, 'No supported interfaces found.'

class DryadShellProtocol(recvline.HistoricRecvLine):
	def __init__(self, user, core):
		self.user = user
		self.core = core
		self.hostname = 'localhost'
		self.controllerName = ''
		self.controllerCommands = []
		self.loadCommands()
	
	def updatePs(self):
		self.ps = ['%s@%s:/%s$ ' % (self.user.username, self.hostname, 
								 self.controllerName)]
	
	def loadController(self, name):
		self.controllerName = name
		self.controller = self.core.pluginmanager.plugins[name]
		self.updatePs()
		controllerMethods = filter(lambda funcname: funcname.startswith('export_'),
								   dir(self.controller))
		self.controllerCommands = [cmd.replace('export_', '', 1) for cmd in controllerMethods]
	
	def loadCommands(self):
		coreMethods = filter(lambda funcname: funcname.startswith('export_'), 
								dir(self))
		self.coreCommands = [cmd.replace('export_', '', 1) for cmd in coreMethods]
	
	def connectionMade(self):
		recvline.HistoricRecvLine.connectionMade(self)
		self.terminal.write('Welcome to the Dryad SSH console.')
		self.terminal.nextLine()
		self.updatePs()
		self.export_help()
		self.showPrompt()
		
	def connectionLost(self, reason):
		log.debug('Disconnect: %s', reason)

	def complete(self, line):
		options = filter(lambda funcname: funcname.startswith(line),
						 self.coreCommands)

		if len(options) == 1:
			self.terminal.eraseLine()
			self.terminal.cursorBackward(99999)
			line = options[0] + ' '
			self.lineBuffer = list(line)
			self.lineBufferIndex = len(line)
			self.drawInputLine()
		elif len(options) > 1:
			self.terminal.nextLine()
			self.terminal.write(' '.join(options))
			self.terminal.nextLine()
			self.drawInputLine()
	
	def showPrompt(self):
		self.terminal.write(self.ps[self.pn])
	
	def getCommandFunc(self, cmd):
		if cmd in self.coreCommands:
			return getattr(self, 'export_' + cmd, None)
		elif cmd in self.controllerCommands:
			return getattr(self.controller, 'export_' + cmd, None)
	
	def handle_TAB(self):
		line = self.currentLineBuffer()[0]
		self.complete(line)
	
	def lineReceived(self, line):
		line = line.strip()
		if line:
			cmdAndArgs = line.split()
			cmd = cmdAndArgs[0]
			args = cmdAndArgs[1:]
			func = self.getCommandFunc(cmd)
			if func:
				try:
					func(*args)
				except Exception, e:
					self.terminal.write('Error: %s' % e)
					self.terminal.nextLine()
			else:
				self.terminal.write('No such command.')
				self.terminal.nextLine()
		self.showPrompt()
	
	def export_help(self, cmd=''):
		if cmd in self.coreCommands:
			func = self.getCommandFunc(cmd)
			if func:
				self.terminal.write(func.__doc__)
				self.terminal.nextLine()
				return
		
		self.terminal.write('Core:\n\t' + ', '.join(self.coreCommands))
		self.terminal.nextLine()
		
		if len(self.controllerCommands) > 0:
			self.terminal.write('%s:\n\t' % self.controllerName +  \
								', '.join(self.controllerCommands))
		self.terminal.nextLine()
		self.terminal.nextLine()
	
	def export_status(self, *args):
		self.terminal.write('Loaded plugins:')
		self.terminal.nextLine()
		self.terminal.write(', '.join(self.core.pluginmanager.plugins))
		self.terminal.nextLine()

	def export_use(self, *args):
		"Select a plugin/controller to be used"
		controller = args[0]
		if controller in self.core.pluginmanager.plugins:
			self.loadController(controller)
		else:
			self.terminal.write('No controller by that name')
			self.terminal.nextLine()
	
	def export_quit(self, *args):
		"Ends your session. Usage: quit"
		self.terminal.write("Bye!")
		self.terminal.nextLine()
		self.terminal.loseConnection()

class DryadFactory(factory.SSHFactory):
	services = {
		'ssh-userauth': userauth.SSHUserAuthServer,
		'ssh-connection': connection.SSHConnection
	}
	
	def __init__(self):
		self.rsaPublicKey = keys.Key.fromString(data=publicKeyText)
		self.rsaPrivateKey = keys.Key.fromString(data=privateKeyText)
		
		self.publicKeys = {
			'ssh-rsa': self.rsaPublicKey
		}
	
		self.privateKeys = {
			'ssh-rsa': self.rsaPrivateKey
		}

class DryadCore(object):
	def __init__(self, port=2925, monitor=False):
		log.info('Dryad core initalized')		
		self.running = False
		self.port = port
		self.sshFactory = DryadFactory()
		self.sshFactory.portal = portal.Portal(DryadRealm(self))
		self.sshFactory.portal.registerChecker(DryadCredentialsChecker())

	def run(self):
		if self.running:
			return
		log.info('Dryad core started')
		self.runnning = True
		reactor.listenTCP(self.port, self.sshFactory)
		reactor.run()
		self.onStopping()
	
	def onStopping(self):
		if hasattr(self, 'monitor'):
			self.monitor.stop()
	
	def stop(self):
		if self.running:
			reactor.stop()
			self.running = False
		log.info('Shutting down..')
		exit(0)