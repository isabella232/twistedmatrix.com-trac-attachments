# -*- coding: utf-8 -*- 
# dryad/client/client.py
#
# Copyright (C) 2008 Damien Churchill <damoxc@gmail.com>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.    See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.    If not, write to:
# 	The Free Software Foundation, Inc.,
# 	51 Franklin Street, Fifth Floor
# 	Boston, MA    02110-1301, USA.
#
#    In addition, as a special exception, the copyright holders give
#    permission to link the code of portions of this program with the OpenSSL
#    library.
#    You must obey the GNU General Public License in all respects for all of
#    the code used other than OpenSSL. If you modify file(s) with this
#    exception, you may extend this exception to your version of the file(s),
#    but you are not obligated to do so. If you do not wish to do so, delete
#    this exception statement from your version. If you delete this exception
#    statement from all source files in the program, then also delete it here.

from twisted.conch.ssh import transport, userauth, connection, common, keys, channel
from twisted.internet import defer, error, protocol, reactor, tcp
from twisted.python import log
import struct, sys, os
import simplejson

publicKeyText = "ssh-rsa AAAAB3NzaC1yc2EAAAABIwAAAQEAz1/O6F0n7+qaES6N7KeBDhrT" \
              "0MHIB330MRdkZNvYq201c5DHYODFU8xrv7aR4EA30ySodu2x3w87tZ4DvaYKCG" \
              "CMquY5PXfYiBFBhFYepvW82ZJPqx6NnpMZm59ug9D5XpfMgnIGjXozcyL7K09O" \
              "kANgIMkEDX7ZHCBphN/uT/hZp6woGB8Y6mcBtiXOj4DiylMMPmz/QE8/2/Or07" \
              "IWkaWm6sD1lWoSFQoiCXVrEiPF+1fmRgJUJwvohScyV0CZPPOgxjSq3yqnhMK6" \
              "TEzY3Tg4mFEnn0vuma1EghT44k4a7VdmE39duGSAKPZdla7ht4ErdYJh2Hmv/2" \
              "A/RxMJEQ=="

privateKeyText = """-----BEGIN RSA PRIVATE KEY-----
MIIEogIBAAKCAQEAz1/O6F0n7+qaES6N7KeBDhrT0MHIB330MRdkZNvYq201c5DH
YODFU8xrv7aR4EA30ySodu2x3w87tZ4DvaYKCGCMquY5PXfYiBFBhFYepvW82ZJP
qx6NnpMZm59ug9D5XpfMgnIGjXozcyL7K09OkANgIMkEDX7ZHCBphN/uT/hZp6wo
GB8Y6mcBtiXOj4DiylMMPmz/QE8/2/Or07IWkaWm6sD1lWoSFQoiCXVrEiPF+1fm
RgJUJwvohScyV0CZPPOgxjSq3yqnhMK6TEzY3Tg4mFEnn0vuma1EghT44k4a7Vdm
E39duGSAKPZdla7ht4ErdYJh2Hmv/2A/RxMJEQIBIwKCAQAF7MtluYTMVyj5LTdB
Rp1Ji7zotRRX/EjOM95MBkgE5dz0rF13y+hhet6B0gQq+oVAjATQMq1PhBemGnUi
rPj47NDRrs5veHPmoWhFnA+BHPbEY0Qa1Py7Y0nf3/vX4WY15xR4wW3myPon3G2T
hexNQezNvJm3PiN11QpUQOmNQY79BI1zfslVHK3g4cACOy+5XQov5eF30BzO91Or
7vLeLpyd3vfgRBJZ4IgvAKQN5LwXqaK6Rwdrf6Vl2M+BR7phquIhi2+I0KyC1kQY
DLR2JECSxXE2XP6L4K6gimtsiqq9cKIxhQY8HITuvlBJzq8Q/QkYhw69WLMPXXr2
T0FHAoGBAO4S/G6Y+ZkJ+NRxsJgMnvDA+P9q8/HUTh/u26X7cUxR1WcT6NpdOLU8
2E8obgNLzK4eu/boNpnvA4/RdccP+hR4B3bDWucMjIH+8wyKbAjg3vcvVUmkznFA
o68skT6T02nGQQWVYytnul3kv4tLLfAAWoM+j6s9QB0+he6J81DbAoGBAN79EGK0
z/k9gmeFl/Y0ymuxoahHCzoKjS+hR5VWlZXfcNZBXDeO4tqOfzRz8PngEWCgaq/m
FbaFlLvHDQyaeAlqjz9syYQeFo+ihF54JCPVZG1X/WOLxrA5UbVilwp3hVlAsDO4
7FgYw/WgMdgzPwJkjmnce7K4GRenEoEQScuDAoGAUaAcCKl6JdeIg1ot6v0DSzrZ
Bx1a89PDA6JZ78PsVK5Xy5HMLZxN9P7rE9NY6y/uZ5WCRgZ5HtWa0jkvsfbZZhqG
N1jr93IESdPBC50sWtDBeVIOnOgMRBYpfeNk/4Mj6cBQzrbgLCOQWrTT9T5Y5JJo
LP+Btw2vlP9+YGnPw/MCgYEAy+AO+yj4qVzO/5AV6GrHsuuMfJi5zqqPtoTTu7zg
iQbNkLDJV14RPNoN5tBnStt9mixESQzgpuCH/CO0KMe+NH6u2ucepK3LfAJNIywD
yP2dpczKaaRd4vKT2Qmuqnvnog9CA2c+fG5qBSS/25yRYUX+jKxT1pmwiqdhYA7k
YksCgYEAz4iCr9Ewm8UAXnd52jUSu1nqAP6c++reOdzHFllfbhP/g6584lY5fl4j
wfgeMyLTHkV7M5DlYPs7W4dBM7+JTwUZR2r1KtoslAqzSYU+WXOKuua44q3uX1Dg
hlJgbjJRVPb8dNJQUGbYCL0lJ2MWcz/Yp3xrBzp2NRpNBj+rQLs=
-----END RSA PRIVATE KEY-----"""

class ClientTransport(transport.SSHClientTransport):
    def __init__(self, user, callback):
        self.user = user
        self.connection = None
        self.callback = callback
        
    def verifyHostKey(self, hostKey, fingerprint):
        return defer.succeed(1)
    
    def connectionSecure(self):
        self.connection = SimpleConnection()
        self.requestService(SimpleUserAuth(self.user, self.connection))
        self.callback(self)

class SimpleUserAuth(userauth.SSHUserAuthClient):
    def getPublicKey(self):
        return keys.Key.fromString(publicKeyText).blob()

    def getPrivateKey(self):
        return defer.succeed(keys.Key.fromString(privateKeyText))

class SimpleConnection(connection.SSHConnection):
    
    def serviceStarted(self):
        self.openChannel(JSONChannel(2**16, 2**15, self))
        self.serviceStartedCallback(self.channels[0])

class JSONChannel(channel.SSHChannel):
    name = 'session'
    
    def __init__(self, localWindow=0, localMaxPacket=0, remoteWindow=0,
                      remoteMaxPacket=0, conn=None, data=None, avatar=None):
        channel.SSHChannel.__init__(self, localWindow, localMaxPacket, 
            remoteWindow, remoteMaxPacket, conn, data, avatar)
        self.deferreds = {}
        self.jsonid = 1
    
    def openFailed(self, reason):
        print 'json failed', reason
        
    def remoteCall(self, method, *params):
        request = {
            'version': '1.1',
            'method': method,
            'params': params,
            'id': self.jsonid
            }
        deferred = defer.Deferred()
        self.deferreds[self.jsonid] = deferred
        self.jsonid += 1
        json = simplejson.dumps(request)
        self.conn.sendRequest(self, 'exec', common.NS(json))
        return deferred
    
    def controllerRemoteCall(self, method, *params):
        pass
    
    def dataReceived(self, data):
        try:
            obj = simplejson.loads(data)
            id = obj['id']
            d = self.deferreds[id]
            if obj.has_key('result'):
                result = obj['result']
                if result:
                    d.callback(result)
                    
            if obj.has_key('error'):
                error = obj['error']
                if error:
                    d.errback(error)
        except:
            pass
    
    def request_exit_status(self, data):
        status = struct.unpack('>L', data)[0]
        print 'json status was: %s' % status
        self.loseConnection()

class DryadTwistedClient(object):
    def __init__(self, callback=None, user='test', host='localhost'):
        self._connected = callback
        self._user = user or os.getlogin()
        self._host = host
        d = protocol.ClientCreator(reactor, \
            ClientTransport, self._user, self._clientConnected \
            ).connectTCP(self._host, 2925)
        d.addErrback(self._connectFailed)
        reactor.run()
    
    def _connectFailed(self, error):
        reactor.stop()
        error.raiseException()
    
    def _clientConnected(self, transport):
        transport.connection.serviceStartedCallback = self._serviceStarted
        
    def _serviceStarted(self, channel):
        self._client = channel
        self._client.channelOpen = self._channelOpen
        
    def _channelOpen(self, specificData):
        self._getMethods()
    
    def _getMethods(self):
        callBack = self._callMethod('systemListMethods')
        callBack.addCallback(self._getMethodsCallback)
    
    def _getMethodsCallback(self, result):
        self._methods = result
        if self._connected:
            self._connected(self)
    
    def _callMethod(self, method, *args):
        return self._client.remoteCall(method, *args)
        
    def _disconnect(self):
        reactor.stop()
    
    def __getattr__(self, name):
        if name not in self._methods:
            raise AttributeError('Unknown method')

        def proxyMethod(method=name, *args):
            return self._callMethod(method, *args)
        return proxyMethod