#!/usr/bin/env python

import xmlrpclib
from sys import argv

#session_id = argv[1]

server = xmlrpclib.Server("http://localhost:8000/xmlrpc")
print "echo?"
print server.echo("test")
