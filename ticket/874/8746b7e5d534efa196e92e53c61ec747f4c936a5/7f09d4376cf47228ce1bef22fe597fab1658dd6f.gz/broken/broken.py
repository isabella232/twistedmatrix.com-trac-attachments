from twisted.python import components
from twisted.application import internet, service
from twisted.internet import protocol, defer, reactor
from twisted.web import xmlrpc, resource, static, server
from twisted.protocols import htb
import os

class RootResource(resource.Resource):

	__implements__ = resource.IResource,

	def __init__(self, service, tracks_path):
		resource.Resource.__init__(self)
		self.service = service
		self.tracks_path = tracks_path
		self.putChild('xmlrpc', SessionXR(self.service))
		self.putChild('tracks', static.File(tracks_path))

	def getChildWithDefault(self, name, request):
		return resource.Resource.getChildWithDefault(self, name, request)


class SessionXR(xmlrpc.XMLRPC):
	"""XMLRPC interface to Listend."""

	def __init__(self, service):
		xmlrpc.XMLRPC.__init__(self)
		self.service = service

	def xmlrpc_echo(self, x):
		"""Return all passed arguments."""
		return x
	xmlrpc_echo.signature = [['string', 'string'],
					['int', 'int'],
					['double', 'double'],
					['array', 'array'],
					['struct','struct']]


class WebClientBucket(htb.Bucket):
	maxburst = None
	rate = None


serverFilter = htb.HierarchicalBucketFilter()
serverBucket = htb.Bucket()

serverFilter.buckets[None] = serverBucket

webFilter = htb.FilterByHost(serverFilter)
webFilter.bucketFactory = WebClientBucket

site = server.Site(RootResource(None, os.path.abspath(os.path.expanduser("~/"))))
site.protocol = htb.ShapedProtocolFactory(site.protocol, webFilter)
setattr(site, "filter", webFilter);

#internet.TCPServer(8000, site)

reactor.listenTCP(8000, site)
reactor.run()
