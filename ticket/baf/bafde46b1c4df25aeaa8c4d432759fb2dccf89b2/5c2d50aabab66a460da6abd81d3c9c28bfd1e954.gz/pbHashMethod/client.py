#!/usr/bin/python -O
# -*- coding: utf-8 -*-
#
# Copyright (c) 2012 WALLIX, SARL. All rights reserved.
#
# Licensed computer software. Property of WALLIX.
# Product name: WALLIX Admin Bastion V 3.0
# Author(s): Nassim Babaci <nbabaci@wallix.com>
# Id: $Id$
# URL: $URL$
# Module description:  $(description)

import sys
from zope.interface import implements
from twisted.spread import pb
from twisted.internet import reactor
from twisted.cred import credentials

from common import MD5doubleHash

class PBUsernamePassword(credentials.UsernamePassword):
    implements(pb.IHashMethod)
    def hashMethod(self, salt, secret):
        return MD5doubleHash(salt, secret)

def loggedIn(perspective):
    def got_username(u):
        print u + " Logged in !"
        reactor.stop()
    perspective.callRemote('username').addCallback(got_username)
    

def ebLogin(fail):
    print "na ! ", fail.type
    reactor.stop()

if __name__ == '__main__':
    u, p = sys.argv[1], sys.argv[2]
    factory = pb.PBClientFactory()
    d = factory.login(PBUsernamePassword(u, p))
    d.addCallbacks(loggedIn, ebLogin)


    reactor.connectTCP("localhost", 8800, factory)
    reactor.run()