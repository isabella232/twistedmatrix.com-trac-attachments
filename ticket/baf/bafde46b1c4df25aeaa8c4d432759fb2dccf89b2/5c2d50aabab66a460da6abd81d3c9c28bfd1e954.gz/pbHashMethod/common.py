#!/usr/bin/python -O
# -*- coding: utf-8 -*-
#
# Copyright (c) 2012 WALLIX, SARL. All rights reserved.
#
# Licensed computer software. Property of WALLIX.
# Product name: WALLIX Admin Bastion V 3.0
# Author(s): Nassim Babaci <nbabaci@wallix.com>
# Id: $Id$
# URL: $URL$
# Module description:  $(description)

from twisted.python.hashlib import md5

# md5.
def MD5doubleHash(salt, secret):
    m = md5()
    m.update(secret)
    hashedPassword = m.digest()
    m = md5()
    m.update(hashedPassword)
    m.update(salt)
    doubleHashedPassword = m.hexdigest()
    doubleHashedPassword += '$$' + salt
    return doubleHashedPassword

def generate_salt(username):
    m = md5()
    m.update(username)
    return m.hexdigest()

if __name__ == '__main__':
    # generate a password file.
    users = {'user': 'password',
             'toto': 'titi'}
    with open('passwd', 'w') as fp:
        for u, p in users.items():
            line = u + ":" + MD5doubleHash(generate_salt(u), p)
            fp.write(line + '\n')

