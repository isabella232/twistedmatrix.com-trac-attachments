#!/usr/bin/python -O
# -*- coding: utf-8 -*-
#
# Copyright (c) 2012 WALLIX, SARL. All rights reserved.
#
# Licensed computer software. Property of WALLIX.
# Product name: WALLIX Admin Bastion V 3.0
# Author(s): Nassim Babaci <nbabaci@wallix.com>
# Id: $Id$
# URL: $URL$
# Module description:  $(description)

from zope.interface import implements
from twisted.spread import pb
from twisted.internet import reactor
from twisted.cred import checkers, portal

from common import MD5doubleHash


class PBFilePasswordChecker(checkers.FilePasswordDB):
    implements(pb.IChallenger)
    def challengeFor(self, username):
        try:
            u, p = self.getUser(username)
        except KeyError:
            return str(len(username))
        _, salt = p.split('$$')
        return salt

    def hashMethod(self, salt, secret):
        return MD5doubleHash(salt, secret)
    
class Avatar(pb.Avatar):
    def __init__(self, username):
        self.username = username

    def perspective_username(self):
        return self.username

class MyRealm(object):
    implements(portal.IRealm)
    def requestAvatar(self, avatarid, client, *interfaces):
        if pb.IPerspective not in interfaces:
            raise NotImplementedError

        return pb.IPerspective, Avatar(avatarid), lambda: None

if __name__ == '__main__':
    portal = portal.Portal(MyRealm())
    portal.registerChecker(PBFilePasswordChecker('passwd', hash=lambda u, p, pp: p))

    factory = pb.PBServerFactory(portal)
    reactor.listenTCP(8800, factory)
    reactor.run()