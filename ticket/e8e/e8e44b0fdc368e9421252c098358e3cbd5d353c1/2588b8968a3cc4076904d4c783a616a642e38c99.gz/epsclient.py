from twisted.spread import pb
from twisted.python import log
from twisted.internet import threads
from emailserver import CopyMessage

class ReceiverMessage(pb.RemoteCopy, CopyMessage):
    pass
pb.setUnjellyableForClass(CopyMessage, ReceiverMessage)

class EPSClient(pb.Root):
    def __init__(self):
        log.msg("EPSClient initialised")

    def remote_takeMessage(self, message):
        log.msg("CLIENT: Message Received")
        print message.from_address

        return "safe and sound" # positive acknowledgement

    def moo(self, result):
        print result
