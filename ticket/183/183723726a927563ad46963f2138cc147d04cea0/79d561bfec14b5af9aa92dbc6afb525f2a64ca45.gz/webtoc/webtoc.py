import os, stat, sys
import twisted.web.microdom as microdom
import twisted.lore.scripts.lore as lore

# These ones get special links on the menu
# Everything else goes into 'Other'
mainTopics = ['howto', 'examples', 'man']

globalIgnores = ['img']

baseDocURL="/doc"
baseOutputPath = '.'
baseDocSourcePath = '.'

indexTemplate = 'webtoc/index-template.tpl'
docTemplate = 'webtoc/website-template.tpl'

#------------------------------------------


def isValidDir(filename, path = baseDocSourcePath):
    """Check whether an entry is a valid directory"""

    fullPath = os.path.join(path, filename)

    # Get rid of things we're ignoring.
    if filename in globalIgnores: return False
    # Get rid of everything except directories.
    if not stat.S_ISDIR(os.stat(fullPath).st_mode): return False
    # Ignore .svn, etc.
    if filename.startswith('.'): return False
    # Ignore things we can't access.
    if not os.access(fullPath, os.R_OK): return False
    # Guess we're ok.
    return True

def isValidFile(filename, path='.'):
    """Check whether an entry is a .xhtml file"""

    fullPath = os.path.join(path, filename)
    if not filename.endswith('.xhtml'): return False
    if not stat.S_ISREG(os.stat(fullPath).st_mode): return False
    if not os.access(fullPath, os.R_OK): return False
    return True

def isRelativeHref(filename):
    if not filename: return False
    if filename[0] in "/#": return False
    if ":" in filename: return False
    return True

def shouldCopyHref(filename):
    """See if this is something we need to copy"""
    
    if filename.endswith(".xhtml"): return False
    if filename.endswith(".html"): return False
    if filename.endswith(".index"): return False
    if '#' in filename: return False
    return True
    
def fixLinks(parse, oldPath, newPath):

    for link in parse.getElementsByTagName('a'):
        href = link.getAttribute('href')
        if not isRelativeHref(href): continue

        # Adjust links to point to website doc path
        newHref = os.path.normpath(os.path.join(
                      baseDocURL, newPath, href))

        link.setAttribute("href", newHref)
 
        # See if we need to copy the file (non-HTML)
        # Or even better, don't.
        #if shouldCopyHref(href):
        #    fromPath = os.path.join(oldPath, href)
        #    toPath = os.path.dirname(os.path.join(newPath, href))
        #    filesToCopy.add( (fromPath, toPath + '/') )

def getTopicIndex(topicBox, project, topic):

    indexDir = os.path.join(baseDocSourcePath, project, topic)
    indexPath = os.path.join(indexDir, 'index.xhtml')
    
    # See if we have an index file
    if not os.access(indexPath, os.R_OK):
        return False
        
    parse = microdom.parse(open(indexPath, 'r'))
    
    newPath = os.path.join(baseOutputPath, project, topic)

    #print "Fixing links for index %s" % indexPath
    fixLinks(parse, indexDir, newPath)
    
    try: body = parse.getElementsByTagName('body')[0]
    except: return False
    
    for node in body.childNodes:
        topicBox.node.appendChild(node)
    
    return True

def parseTopicFiles(topicBox, project, topic, addTitle = False):
    
    topicPath = os.path.join(baseDocSourcePath, project, topic)

    # Get a list of files in this topic
    files = [x for x in os.listdir(topicPath) if isValidFile(x, topicPath)]
    
    for thisFile in files:

        filePath = os.path.join(topicPath, thisFile)

        parse = microdom.parse(open(filePath, 'r')) 

        #print "Fixing links for %s" % filePath
        fixLinks(parse, topicPath, os.path.join(baseOutputPath, project, topic))        
        if addTitle:
            topicBox.text("- ")        
            title = parse.getElementsByTagName('title')[0].firstChild().nodeValue
            if not title: title = thisFile
        
            fileURL = os.path.join(baseDocURL, project, topic, thisFile)
            link = topicBox.add("a", href=fileURL)
            link.text(title)
            topicBox.add("br")

def getProjectTopics(project):
    """Enumerate documentation types within a project"""
    path = os.path.join(baseDocSourcePath, project)
    return [x for x in os.listdir(path) if isValidDir(x, path)]

def createHTMLBits(tree, title, navBox = None):
    tree.add("head").add("title").text(title)
    body = tree.add("body")
    if navBox: body.node.appendChild(navBox.node)
    return body

def addNewsBox(tree, project):
    # This code looks strange because "class" is a Python keyword
    # And so can't be passed as a kwarg to add()
    entry = tree.add("div")
    entry['class'] = "newsentry"
    entry.add("div").text(project.capitalize())['class'] = 'newssubject'
    box = entry.add("div")
    box['class'] = 'newsbody'
    return box

def doTopicBox(project, topic, box):
    url = "/".join([baseDocURL, project, topic])
    box.text("- ")
    link = box.add("a", href=url)
    link.text(topic.capitalize())
    box.add("br")
    
    # If we care about this topic, add it to a tree
    if topic in mainTopics: tree = topicTrees[topic]
    else: tree = topicTrees['other']
    
    topicBox = addNewsBox(tree, project)
    
    haveIndex = getTopicIndex(topicBox, project, topic)
    parseTopicFiles(topicBox, project, topic, not haveIndex)

def getOutputFileName(originalFileName, outputExtension, index=None):

    if originalFileName.startswith(baseDocSourcePath):
        originalFileName = originalFileName[
                               len(baseDocSourcePath):].lstrip('/')

    return os.path.join(baseOutputPath,
                      os.path.splitext(
                         originalFileName)[0]+outputExtension)

def copyFiles():
    """This function is not used, because it is Silly."""
    for fromPath, toPath in filesToCopy:

        if not os.access(fromPath, os.F_OK):
            print "Missing file: %s" % fromPath
            continue

        if not os.access(toPath, os.F_OK):
            try: os.makedirs(toPath) 
            except Exception, e:
                print "Couldn't create %s" % toPath
                print e
                continue

        try: shutil.copy(fromPath, toPath)
        except Exception, e:
            print "Failed to copy %s to %s" % (fromPath, toPath)
            print e

def runLore():
    print "Running Lore on indexes"
    opt = lore.Options()
    opt.parseOptions()
    # Use index template
    opt.config['template'] = indexTemplate
    # Parse .index files
    opt['inputext'] = '.index'
    opt['docsdir'] = baseOutputPath

    # Redirect outputs to the website doc directory
    lore.process.tree.getOutputFileName = getOutputFileName

    lore.runGivenOptions(opt)
    
    print "Running Lore on documents"
    opt.config['template'] = docTemplate
    opt['inputext'] = '.xhtml'
    opt['docsdir'] = baseDocSourcePath
    lore.runGivenOptions(opt)    

if __name__ == "__main__":

    # Get a list of projects
    projects = [x for x in os.listdir(baseDocSourcePath) if isValidDir(x)]
    projects.sort()

    print "Generating indexes"
    
    # XML tree for the main page (by project)
    projectXML = microdom.lmx()
    projectTree = createHTMLBits(projectXML, "Topics By Project")

    # Trees for each topic
    topicXMLs = {}
    topicTrees = {}
    for topic in mainTopics + ['other']:
        topicXMLs[topic] = microdom.lmx()
        topicTrees[topic] = createHTMLBits(
            topicXMLs[topic],
            "Documentation - %s" % topic.capitalize())

    for project in projects:

        topics = getProjectTopics(project)

        # Ignore projects which appear to have no documentation
        atLeastOneRelevantTopic = False
        for topic in topics:
            if topic in mainTopics:
                atLeastOneRelevantTopic = True
        if not atLeastOneRelevantTopic: continue
            
        box = addNewsBox(projectTree, project)
        
        for topic in topics:
            doTopicBox(project, topic, box)
            
    # Write the main project index
    d = microdom.Document(projectXML.node)
    d.writeprettyxml(open(
        os.path.join(baseOutputPath, "index.index"), 'w'))

    # Write the topic indexes
    for topic, tree in topicXMLs.items():
        d = microdom.Document(tree.node)
        d.writeprettyxml(open(
            os.path.join(baseOutputPath, "%s.index" % topic),'w'))

    # Copy missing files
    #print "Copying %s non-HTML files" % len(filesToCopy)
    #copyFiles()
    
    runLore()

                              
