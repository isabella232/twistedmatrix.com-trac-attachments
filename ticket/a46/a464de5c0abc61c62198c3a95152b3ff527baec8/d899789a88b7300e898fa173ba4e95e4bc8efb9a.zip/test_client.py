from twisted.python import failure
from twisted.trial import unittest

from twisted.internet import protocol, interfaces, defer, reactor

import http as httpMain

from twisted.web2 import http_headers, http
from twisted.web2 import server, channel, resource
#import server,channel,resource

from twisted.web2 import stream

import sys,random,time,traceback,os,cPickle as pickle

class AttrReplacer:
	"""Temporarily replace attributes in an intelligent manner.
	Restore those attributes on exit, to attempt to isolate state changes.
	"""
	def __init__(self):
		self._restore = list()
		self.restored = True
	def set(self,obj,name,value):
		oldAttr = getattr(obj,name)
		self._restore.append((obj,name,oldAttr))
		if callable(value):
			self.setMethod(obj,name,value,oldAttr)
		else:
			setattr(obj,name,value)
		self.restored = False
	def setMethod(self,obj,name,func,oldAttr):
		def method(*args,**kw):
			return func(oldAttr,*args,**kw)
		method.__name__ = func.__name__ # oldAttr.__name__
		setattr(obj,name,method)
	def restore(self):
		if self.restored: return
		self.restored = True
		# Restore in reverse order that we set:
		self._restore.reverse()
		for obj,name,value in self._restore:
			#print "Restoring %s to %s" % (name,obj)
			setattr(obj,name,value)
	def restoreCB(self,k):
		self.restore()
		return k
	def __del__(self):
		self.restore()

def findUnusedPort():
	"""Find one unused port.
	@return: a Deferred that will fire when the port is found and ready
	"""
	p = reactor.listenTCP(0,protocol.Factory())
	port = p.getHost().port
	def setThePort(p):
		return port
	d = p.stopListening()
	d.addCallback(setThePort)
	def error(p):
		print "Couldn't find unused port!",p
		reactor.stop()
		raise SystemExit
	d.addErrback(error)
	return d

def findUnusedPorts(n):
	"""Find n unused ports. 
	This is a convenience function for a DeferredList.
	"""
	def removeTruth(results):
		return tuple(item[1] for item in results)
	d = defer.DeferredList(tuple(findUnusedPort() for port in range(n)))
	d.addCallback(removeTruth)
	return d

class DelayedChild(resource.Resource):
	"""A resource that renders slowly
	"""
	addSlash = False
	def render(self, ctx):
		s=stream.ProducerStream()
		self.slowrender(s,4)
		return http.Response(stream=s)
	def slowrender(self,s,count):
		if count <= 0:
			s.finish()
		else:
			s.write("do de do\r\n")
			reactor.callLater(random.randrange(1,10)/10.0,self.slowrender,s,count-1)

class BarChild(resource.Resource):
	"""Just a test child resource
	Is it loli????
	"""
	def render(self,ctx):
		return http.Response(stream="I'm under 21!")

class PutChild(resource.Resource):
	"""A resource that supports (ignores) PUT
	"""
	def http_PUT(self,ctx):
		return http.Response(code=202,stream='')

class HeaderChild(resource.Resource):
	"""A resource that doesn't understand Pokemon
	Also it responds with some headers, or an error if headers
	are missing from the request.
	"""
	addSlash = False
	def render(self,ctx):
		#print "ctx",list(ctx.headers.getAllRawHeaders())
		if ctx.headers.hasHeader('Accept-Language') and \
			ctx.headers.hasHeader('X-My-Other-Header'):
			resp = http.Response(stream="blackie -> eevee")
			resp.headers.setRawHeaders('X-Exotic-Headers',['OK'])
		else:
			resp = http.Response(code=501,stream="FAIL")
		return resp

from twisted.web2.channel.http import PERSIST_PIPELINE, PERSIST_NO_PIPELINE

class BadChild(resource.Resource):
	""""A bad child, who returns data in their response to a HEAD request"""
	addSlash = False
	def http_HEAD(self,ctx):
		connectionPolicy = ctx.chanRequest.channel.readPersistent
		#print "OOH, BAD SERVER",connectionPolicy
		#if ctx.headers.hasHeader('Connection'):
		#	print 'BAD SERVER',ctx.headers.getRawHeaders('Connection')
		resp = http.Response(stream='POOPY',headers={'Content-Length':5})
		return resp

class TestServer(resource.Resource):
	"""A resource that has children.
	It also responds with junk data, or with information on the connection
	type for HEAD requests.
	"""
	child_delayed = DelayedChild()
	child_bar = BarChild()
	child_checkheaders = HeaderChild()
	child_putter = PutChild()
	child_bad = BadChild()
	addSlash = True
	def render(self, ctx):
		return http.Response(stream="1234567890")
	def http_HEAD(self,ctx):
		connectionPolicy = ctx.chanRequest.channel.readPersistent
		#print "OOH, BAD SERVER",connectionPolicy
		#if ctx.headers.hasHeader('Connection'):
		#	print 'BAD SERVER',ctx.headers.getRawHeaders('Connection')
		resp = http.Response(stream='',headers={'Content-Length': 0})
		resp.headers.setRawHeaders('X-Connection-Type',[str(connectionPolicy)])
		#print "Sending headers",list(resp.headers.getAllRawHeaders())
		#print list(ctx.headers.getAllRawHeaders())
		return resp

class RawServer(protocol.ServerFactory):
	"""A really stupid server
	This swallows data while it comes in. If no data comes during the
	delay period, the server calls the gotData member of the factory,
	which must be set by the test case."""
	def gotData(self,proto,data):
		raise RuntimeError("Should not get data yet! %s" % data)
	class Protocol(protocol.Protocol):
		data = ''
		delay = 0.1
		def __init__(self):
			#print "Init protocol"
			self.timeout = None
		def fireResponse(self):
			#print "Fire response!"
			self.gotData(self,self.data)
			self.data = ''
		def respond(self,data):
			self.transport.write(data)
		def dataReceived(self,data):
			self.data += data
			if self.timeout:
				reactor.cancelCallLater(self.timeout)
			# Since this is on a LAN "simulated" network
			# we can afford to be impatient:
			self.timeout = reactor.callLater(self.delay,self.fireResponse)
	def buildProtocol(self,addr):
		self.proto = protocol.Factory.buildProtocol(self,addr)
		self.proto.gotData = self.gotData
		return self.proto
	protocol = Protocol

def testSrv(port):
	"""Generate the main test server"""
	srv = TestServer()
	site = server.Site(srv)
	factory = channel.HTTPFactory(site)
	factory.host = '127.0.0.1'
	factory.port = port

	port = reactor.listenTCP(port, factory)
	return port,srv,factory

def rawSrv(port):
	"""Generate the raw server"""
	factory = RawServer()
	factory.host = '127.0.0.1'
	factory.port = port
	port = reactor.listenTCP(port,factory)
	return port,factory

def testCli(port):
	"""Generate the client I will be testing."""
	factory = httpMain.Factory(reactor)
	return factory

class Connector:
	"""Just a container class to hold all the client and server info"""
	def __init__(self,ports):
		self.port,self.site,self.server = testSrv(ports[0])
		self.rawport,self.rawServer = rawSrv(ports[1])
		self.client = testCli(ports[0])

# Since you can't send any contextual data to a trial, it has to be global
global ctor

class ClientTests(unittest.TestCase):
	def assertHeaders(self, resp, expectedHeaders):
		"""Assert the expected headers are in the response."""
		headers = resp.headers
		for header in expectedHeaders:
			#print header[0],header[1],headers.getRawHeaders(header[0])
			#print str(header[1]) in headers.getRawHeaders(header[0])
			self.assertTrue(headers.hasHeader(header[0]),'Required header %s not found' % (header,))
			results = headers.getRawHeaders(header[0])
			self.assertTrue(
				str(header[1]) in headers.getRawHeaders(header[0]),
				'Required header %r had no %r good values %r' % (header[0],header[1],results)
			)

	def checkResponse(self, resp, code, headers, data):
		"""
		Assert various things about a response: http code, headers, stream
		length, and data in stream.

		@return: deferred when there is data to be read, None when there is not
		"""

		class Collector:
			"Make sure the data is what we expect"
			def __init__(kid):
				kid.data = list()
			def consume(kid,datum):
				kid.data.append(datum)
			def check(kid,none):
				self.assertEquals(''.join(kid.data),data)
		
		self.assertEquals(str(resp.code), str(code))
		self.assertHeaders(resp.response, headers)

		if data:
			if resp.stream.length is not None:
				self.assertEquals(resp.stream.length, len(data))
			c = Collector()
			d = stream.readStream(resp.stream, c.consume)
			d.addCallback(c.check)
			return d

class TestHTTPClient(ClientTests):
	"""Test that the http client works."""
	def test_noPersistenceWorksToo(self):
		"""
		Ensure that disabling persistence completes the requests too.
		"""
		ctor.server.protocolArgs['allowPersistentConnections'] = False
		ctor.server.protocolArgs['maxPipeline'] = 4
		return self.do_prematurePipelining()

	def test_prematurePipeliningnoPipe(self):
		"""
		Ensure that queueing a second request is allowed even if pipelining
		is not yet. This one tests with no pipelining, but persistence
		"""
		ctor.server.protocolArgs['allowPersistentConnections'] = True
		ctor.server.protocolArgs['maxPipeline'] = 0
		return self.do_prematurePipelining()

	def test_prematurePipeliningnoPipenoPersist(self):
		"""
		Ensure that queueing a second request is allowed even if pipelining
		is not yet. This one tests with no pipelining, no persistence.
		"""
		ctor.server.protocolArgs['allowPersistentConnections'] = False
		ctor.server.protocolArgs['maxPipeline'] = 0
		return self.do_prematurePipelining()

	def do_prematurePipelining(self):
		"""
		Excecutes one of a combination of tests
		"""
		
		requests = (
			httpMain.ClientRequest('GET', '/'),
			httpMain.ClientRequest('GET', '/bar'),
			httpMain.ClientRequest('GET', '/bar'),
		)
		allOK = defer.Deferred()

		class Gotter:
			responsesLeft = len(requests)
			def done(self,thing):
				self.responsesLeft -= 1
				#print "DOne!",self.responsesLeft,"left"
				if self.responsesLeft <= 0:
					# Once we received responses from all requests, we're cool
					allOK.callback(True)
			def peep(self,data):
				pass#print "peep",data
			def gotResponse(kid,resp):
				#print "Gotted",resp.code
				return stream.readStream(resp.stream, kid.peep)

		g = Gotter()

		for req in requests:
			req.host = ctor.server.host
			req.port = ctor.server.port
			ctor.client.addRequest(req)
			req.responseReceived.addCallback(g.gotResponse)
			req.contentReceived.addCallback(g.done)

		def resetParameters(x):
			ctor.server.protocolArgs['allowPersistentConnections'] = True
			ctor.server.protocolArgs['maxPipeline'] = 4
			return x

		allOK.addCallbacks(resetParameters,resetParameters)

		return allOK

	def test_delayedContent(self):
		"""
		Make sure that the client returns the response object as soon as the
		headers are received, even if the data hasn't arrived yet.
		"""
		
		allOK = defer.Deferred()
		class Gotter:
			def nowDone(kid,resp):
				doneTime = time.time()
				if doneTime-1 > self.headTime:
					allOK.callback(True)
				else:
					allOK.errback(ValueError("Headers were delayed until the end of data"))
			def peep(kid,data):
				pass#print "Peep",data
			def gotResponse(kid,resp):
				#print "Gotted",resp.code
				# Now is when the head is here, and we stream the data
				self.headTime = time.time()
				return stream.readStream(resp.stream, kid.peep)

		req = httpMain.ClientRequest('GET', '/delayed')
		g = Gotter()
		req.responseReceived.addCallback(g.gotResponse)
		req.contentReceived.addCallback(g.nowDone)

		req.host = ctor.server.host
		req.port = ctor.server.port

		ctor.client.addRequest(req)
		
		return allOK

	def test_simpleRequest(self):
		"""Your basic simple HTTP Request."""

		allOK = defer.Deferred()

		def gotResponse(kid):
			#print "Gotted"
			try:
				d = self.checkResponse(kid,200,[],'1234567890')
			except Exception,e:
				print "eee",e
				allOK.errback(e)
			d.addCallback(lambda k: allOK.callback(True))
			d.addErrback(lambda e: allOK.errback(e))
			return d

		req = httpMain.ClientRequest('GET', '/')
		d = req.responseReceived
		d.addCallback(gotResponse)

		req.host = ctor.server.host
		req.port = ctor.server.port

		ctor.client.addRequest(req)
		return allOK
	def test_sendHeaders(self):
		"""Make sure that we can send and receive custom headers."""
		
		allOK = defer.Deferred()

		def gotResponse(resp):
			try:
				d = self.checkResponse(resp,200,[('X-Exotic-Headers','OK')],'blackie -> eevee')
				allOK.callback(True)
			except Exception,e:
				print "eee",e
				allOK.errback(e)
				raise

		headers = http_headers.Headers(
			headers={'Accept-Language': {'en': 1.0},'Host': 'localhost'},
			rawHeaders={'X-My-Other-Header': ['socks']})
		req = httpMain.ClientRequest('GET', '/checkheaders', headers)
		d = req.responseReceived
		d.addCallback(gotResponse)

		req.host = ctor.server.host
		req.port = ctor.server.port

		ctor.client.addRequest(req)
		return allOK
		
	def test_streamedUpload(self):
		"""Make sure that sending request content works."""

		allOK = defer.Deferred()

		def gotResponse(resp):
			try:
				d = self.checkResponse(resp,202,[],'')
				allOK.callback(True)
			except Exception,e:
				print "eee",e
				allOK.errback(e)
				raise

		req = httpMain.ClientRequest('PUT', '/putter', stream='Helloooo content')
		d = req.responseReceived
		d.addCallback(gotResponse)

		req.host = ctor.server.host
		req.port = ctor.server.port

		ctor.client.addRequest(req)
	def test_sentHead(self):
		"""Ensure that HEAD requests work, and return Content-Length."""

		allOK = defer.Deferred()

		def gotResponse(resp):
			headers = resp.response.headers
			try:
				if headers.hasHeader('Content-Length') and \
					headers.getHeader('Content-Length')== 0:
					allOK.callback(True)
				else:
					allOK.errback(ValueError("Missing content length"))
			except Exception,e:
				print 'goo',e
				raise
			return stream.readStream(resp.stream, lambda x: None)
		req = httpMain.ClientRequest('HEAD', '/')
		req.responseReceived.addCallback(gotResponse)

		req.host = ctor.server.host
		req.port = ctor.server.port

		ctor.client.addRequest(req)
		return allOK

	def test_sentHeadKeepAlive(self):
		"""Ensure that keepalive works right after a HEAD request."""

		allOK = defer.Deferred()
		rep = AttrReplacer()
		allOK.addCallbacks(rep.restoreCB,rep.restoreCB)	

		def resetParameters(x):
			ctor.server.protocolArgs['maxPipeline'] = 4
			return x
		allOK.addCallbacks(resetParameters,resetParameters)
		ctor.server.protocolArgs['maxPipeline'] = 0

		rep.set(ctor.client,'maxPipesPerHost',1)

		def check(http_HEAD,ctx):
			connType = ctx.chanRequest.connHeaders.getHeader('connection')[0]
			self.assertEquals(
				ctx.headers.getRawHeaders('X-Connection-Should-Be')[0],
				connType)
			resp = http.Response(stream="")
			resp.headers.setRawHeaders('X-Connection-Type',[connType])
			return resp
		
		rep.set(ctor.site,'http_HEAD',check)

		class Gotter:
			gotFirst = False
			gotSecond = True
			def firstHead(kid,resp):
				#print "Got the first one"
				kid.gotFirst = True
				try:
					self.checkResponse(resp, 200, [('X-Connection-Type','keep-alive')], None)
				except Exception,e:
					traceback.print_exc()
					print "1eee",e
					allOK.errback(e)
					raise
			def secondHead(kid,resp):
				#print "Got the second one",kid.gotFirst
				if not kid.gotFirst:
					return allOK.errback(ValueError("Shouldn't get the second before the first response"))
				try:
					self.checkResponse(resp, 200, [('X-Connection-Type','close')], None)
				except Exception,e:
					print "2eee",e
					allOK.errback(e)
					raise
				#print "Waiting for the connection to close..."
				d = resp.channel.transport.loseConnection()
				if d:
					d.addCallback(kid.gotClosed)
				else:
					kid.gotClosed(None)
			def gotClosed(kid,huh):
				#print "Got connection lost!"
				self.assertTrue(kid.gotFirst and kid.gotSecond, "We missed getting a page.")
				allOK.callback(True)
		g = Gotter()

		requests = (
			httpMain.ClientRequest('HEAD', '/', {'Connection': ['keep-alive']}),
			httpMain.ClientRequest('HEAD', '/', {'Connection': ['close']})
		)
		responders = (
			g.firstHead,
			g.secondHead
		)
		rep.set(ctor.client,'connectionPolicy','snarky') # should never be used

		for i in range(len(requests)):
			requests[i].headers.setRawHeaders('X-Connection-Should-Be',requests[i].headers.getHeader('connection'))
			requests[i].responseReceived.addCallback(responders[i])

			requests[i].host = ctor.server.host
			requests[i].port = ctor.server.port

			#print "Sending",i

			ctor.client.addRequest(requests[i])

		return allOK

	def test_chunkedUpload(self):
		"""Ensure chunked data is correctly decoded on upload."""
		
		allOK = defer.Deferred()

		inputStr = "dooby doo bee doo"

		req = httpMain.ClientRequest('PUT', '/putter', stream=inputStr,chunkedOut=True,
			host = ctor.rawServer.host,
			port = ctor.rawServer.port)

		def check(proto,data):
			testStr = '%X\r\n%s\r\n0\r\n\r\n' % (len(inputStr), inputStr)
			try:
				self.assertTrue(len(proto.data)>=len(testStr),"Bad data length")
				self.assertTrue(proto.data.endswith(testStr),"Data ended with %r" % proto.data[-len(testStr):])
			except Exception,e:
				allOK.errback(e)
				return
			allOK.callback(True)
			proto.respond("\r\n".join((
				'HTTP/1.1 200 OK',
				'Connection: close',
				'Content-Length: 0',
				'')))
		ctor.rawServer.gotData = check

		ctor.client.addRequest(req)
		return allOK

class TestEdgeCases(ClientTests):
	def test_serverDoesntSendConnectionClose(self):
		"""
		Check that a lost connection is treated as end of response, if we
		requested connection: close, even if the server didn't respond with
		connection: close.
		"""

		req = httpMain.ClientRequest('GET', '/', {'Connection': ['close']})
		req.responseReceived.addCallback(self.checkResponse, 200, [], 'Some Content')

		req.host = ctor.rawServer.host
		req.port = ctor.rawServer.port


		def respond(proto,data):
			headers = data.strip().split("\r\n")
			expectedHeaders = (
				'GET / HTTP/1.1',
				'Host: 127.0.0.1',
				'Connection: close',
			)
			for e in expectedHeaders:
				self.assertTrue(e in headers,"Required header %r not found" % e)
			proto.transport.write('\r\n'.join((
				'HTTP/1.1 200 OK',
				'',
				'Some Content')))
			proto.transport.loseConnection()

		ctor.rawServer.gotData = respond
		ctor.client.addRequest(req)

		return req.responseReceived

	def do_funkyResponse(self,errorCode,errorMessage,*response):
		"""Check that an error is returned if the server doesn't talk HTTP."""

		req = httpMain.ClientRequest('GET', '/', {'Connection': ['close']},
			host=ctor.rawServer.host,port=ctor.rawServer.port)

		def respond(proto,data):
			headers = data.strip().split("\r\n")
			expectedHeaders = (
				'GET / HTTP/1.1',
				'Host: 127.0.0.1',
				'Connection: close',
			)
			for e in expectedHeaders:
				self.assertTrue(e in headers,"Required header %r not found in %s" % (e,headers))
			proto.transport.write('\r\n'.join(response)+'\r\n'*2)
		ctor.rawServer.gotData = respond

		def badResponse(resp):
			raise self.failureException("Should not get to response")
		req.responseReceived.addCallback(badResponse)

		def assuredFailure(r):
			#print "Final failure check"
			self.assertEquals(r.code(),errorCode,"Code for %s failed, expected %d" % (r,errorCode))
			self.assertEquals(r.message(),errorMessage,"Message for %s failed expected %s" % (r,errorMessage))
			return r
		d = self.assertFailure(req.headersReceived,httpMain.ProtocolError)
		d.addCallback(assuredFailure)

		ctor.client.addRequest(req)
		return d

	def test_serverIsntHttp(self):
		"""Make sure there is an error when the server is not HTTP"""
		return self.do_funkyResponse(400,'Unknown protocol: HTTP-NG/1.1',
			'HTTP-NG/1.1 200 OK',
			'',
			'Some Content')
	def test_newServer(self):
		"""Make sure there is an error when the server is too new a version of HTTP"""
		return self.do_funkyResponse(505,'Only HTTP 1.x is supported.',
			'HTTP/2.3 200 OK',
			'',
			'Some Content')
	def test_shortStatus(self):
		"""Check that an error is returned if the response line is truncated."""

		return self.do_funkyResponse(400,'Bad response line: HTTP/1.1 200',
			'HTTP/1.1 200',
			'',
			'Some Content')
	def test_errorReadingRequestStream(self):
		"""Ensure that stream errors are propagated to the response."""
		s = stream.ProducerStream()
		s.write('Foo')
		req = httpMain.ClientRequest('GET', '/', stream=s)

		req.host = ctor.server.host
		req.port = ctor.server.port

		ctor.client.addRequest(req)
		return req.responseReceived.addCallback(lambda resp: self.checkResponse(resp,413,[],None))

class MyJanitor(object):
	"""A lazy janitor that doesn't worry about selectables
	Since I need one selectable for each server, I can't dumbly error out
	when there are any selectables.
	TODO: error out when there are selectables besides the persistent ones
	"""
	logErrCheck = True
	cleanPending = cleanThreads = cleanReactor = True

	def postCaseCleanup(self): pass

	def postClassCleanup(self): pass
	
	def __getattr__(self,name):
		raise AttributeError("Attribute??? "+name)

def main(ports):
	print "Port is",ports
	from twisted.trial import util
	util._Janitor = MyJanitor #XXX: this should be overridable

	from twisted.trial import runner, reporter
	_runner = runner.TrialRunner(
		reporter.TreeReporter,
#		mode=runner.TrialRunner.DEBUG,
		tracebackFormat='default',
	)
	loader = runner.TestLoader()
	print "Running suite!"
	global ctor
	ctor = Connector(ports)
	#suite = loader.loadClass(TestHTTPClient)
	#suite = loader.loadClass(TestEdgeCases)
	#suite = loader.loadMethod(TestHTTPClient.test_sentHeadKeepAlive)
	suite = loader.loadModule(sys.modules[__name__])
	result = _runner.run(suite)
	ctor.client.abort()
	print "Done."
	#reactor.stop()
	return False

if sys.argv[0].find('trial')!=-1:
	print """
********************************************************************
    Do not run me with the trial command.
    Since I have to wait for open ports, I run trial myself after that.
********************************************************************
	"""
	os.execvp('python',('python',)+tuple(sys.argv[1:]))
	raise SystemExit

if __name__=='__main__':	
#	d = findUnusedPorts(2)
#	d.addCallback(main)
#	process = ServerProcess()
	reactor.callLater(0.1,main,(14444,14445))
	reactor.run()
