from twisted.internet import defer, protocol, reactor,error
from twisted.protocols import basic, policies
from twisted.web2 import stream as stream_mod, http, http_headers, responsecode
from twisted.web2.channel import http as httpchan
from twisted.web2.channel.http import PERSIST_NO_PIPELINE, PERSIST_PIPELINE

############################################################################
# from twisted.internet.defer import OneTask?

taskDelay = 0.1

# Note: running these may cancel pending deferred calls
# cancelling these should never raise an exception

class OneTask:
	"""An object that can only do one task at a time.
	It kind of works like an auto-cancelling callLater."""
	task = None
	def run(self,task,*args,**kw):
		"""Run a new task, cancel the old one if it's not fired yet.
		"""
		self.cancel()
		self.task = reactor.callLater(taskDelay,task,*args,**kw)
	def cancel(self):
		if self.task:
			try:
				self.task.cancel()
			except (error.AlreadyCancelled,error.AlreadyCalled): pass
			del self.task

############################################################################

try:
	from collections import defaultdict
except ImportError:
	########################################################################
	# from twisted.python.oldcompatibility import defaultdict?
	class defaultdict(dict):
		def __init__(self,type_):
			self.type = type_
		def __setitem__(self,name,item):
			if not isinstance(item,self.type):
				raise TypeError("This dict only accepts %s" % self.type)
			return dict.__setitem__(self,name,item)
		def __getitem__(self,name):
			try:
				return dict.__getitem__(self,name)
			except KeyError:
				obj = self.type()
				self[name] = obj
				return obj
	########################################################################

import socket
from urlparse import urlparse

#XXX: 423 is easier to remember than -1248934024900
def myid(o):
	return id(o) % 1024

class ProtocolError(Exception):
	def code(self):
		return self.args[0]
	def message(self):
		return self.args[1]

class ClientRequest(object):
	"""A class for describing an HTTP request to be sent to the server.
	"""

	_host = None
	port = 80

	def _get_host(self):
		return self._host
	def _set_host(self,what):
		if what is None: return
		if not self.headers.hasHeader('host'):
			self.headers.setHeader('host',what)
		self._host = what
	def _del_host(self):
		del self._host
	host = property(_get_host,_set_host,_del_host)

	def __init__(self, method, uri, headers=None, stream=None, chunkedOut=False,host=None, port=None):
		"""
		@param method: The HTTP method to for this request, ex: 'GET', 'HEAD',
			'POST', etc.
		@type method: C{str}
		
		@param uri: The URI of the resource to request, this may be absolute or
			relative, however the interpretation of this URI is left up to the 
			remote server.
		@type uri: C{str}

		@param headers: Headers to be sent to the server.
			This object will create implicit headers, if they do not 
			exist already, such as Host.
		@type headers: C{dict}, L{twisted.web2.http_headers.Headers}, or 
			C{None}
	
		@param stream: Content body to send to the remote HTTP server.
		@type stream: L{twisted.web2.stream.IByteStream}

		@param host: Host to connect to (will override uri host)
		@type host: C{str}

		@param port: Port to connect to (will override uri port)
		@type port: C{str}
		"""

		self.method = method
		self.uri = uri
		if isinstance(headers, http_headers.Headers):
			self.headers = headers
		else:
			self.headers = http_headers.Headers(headers or {})

		if stream is not None:
			self.stream = stream_mod.IByteStream(stream)
		else:
			self.stream = None

		self.chunkedOut = chunkedOut

		if not (host and port):
			bits = urlparse(uri)
			if ':' in bits[1]:
				h,p = bits[1].split(':')
			elif bits[1]:
				h = bits[1]
				try:
					# XXX: will this block?
					name = bits[0]
					if not name: name = 'http'
					p = socket.getservbyname(name)
				except socket.error:
					p = 80
			else:
				h = ClientRequest._host
				p = ClientRequest.port

			if self.headers.hasHeader('host'):
				h = self.headers.getHeader('host')

			if not host: host = h
			if not port: port = p
		
		self.host = host
		self.port = port

		def error(e):
			print "Something went horribly wrong!" % e
			return e
		
		# Fired (by channel below) when this request is complete
		self.contentReceived = defer.Deferred()
		self.headersReceived = defer.Deferred()
		self.responseReceived = defer.Deferred()
		#self.contentReceived.addErrback(error)
		#self.headersReceived.addErrback(error)
		#self.responseReceived.addErrback(error)

class HTTPClientChannelRequest(httpchan.HTTPParser):
	"""A proto.
	This handles submitting a ClientRequest and handling its response.
	The Protocol (aka the channel) handles which piece of data
	goes to which proto. Once a proto has finished its
	response, it notifies the channel to move on to the next response.
	"""
	parseCloseAsEnd = True
	outgoing_version = "HTTP/1.1"
	chunkedOut = False
	finished = False
	
	contentLength = None
	producer = None

	def _get_transport(self):
		return self.channel.transport
	def _set_transport(self,t):
		raise ValueError("Arg!")
	def _del_transport(self):
		pass

	transport = property(_get_transport,_set_transport,_del_transport)
	
	def __init__(self, channel, request):
		"""
		@param channel: The HTTP protocol for this connection
		@type channel: C{HTTPClientProtocol}
		
		@param request: The request we are seeking a response to
		@type request: C{ClientRequest}

		We're going to keep the policy on connection closing strictly decided
		by the request Connection: header.
		"""

		httpchan.HTTPParser.__init__(self, channel)
		self.request = request
		
		if not request.headers.hasHeader('connection'):
			# We need to have a connection header
			# Go for the factory default
			request.headers.setHeader(
				'connection',
				[self.channel.factory.connectionPolicy])

	# consumer interface, for convenience assigning producers to me
	def registerProducer(self, producer, streaming):
		if self.producer:
			raise ValueError, "registering producer %s before previous one (%s) was unregistered" % (producer, self.producer)
		
		self.producer = producer
		
		if not hasattr(self,'transport'):
			raise ValueError("Can't produce no transport")

		self.transport.registerProducer(producer, streaming)

	def unregisterProducer(self):
		if hasattr(self,'transport'):
			self.transport.unregisterProducer()
		self.producer = None

	# The algorithm goes like:
	# 1) headers are received
	# 2) allHeadersReceived() is called
	# 3) split off connection headers
	# 4) createRequest() is called (to create Response)
	# 5) processRequest() is called
	# 6) data is received
	# 7) allContentReceived() is called

	def allHeadersReceived(self):
		httpchan.HTTPParser.allHeadersReceived(self) # set .length
		self.contentLength = self.length
		# self.length gets decremented, will be 0 after content received
		if self.request.headersReceived:
			self.request.headersReceived.callback(self)

	def allContentReceived(self):
		httpchan.HTTPParser.allContentReceived(self)
		if self.request.contentReceived:
			self.request.contentReceived.callback(self)
		if self.request.headers.getHeader('connection')=='close':
			self.transport.loseConnection()

	## FIXME: Actually creates Response, function is badly named!
	## FIXME: parent class needs to be patched for this.
	def createRequest(self):
		self.stream = stream_mod.ProducerStream(self.length)
		self.response = http.Response(self.code, self.inHeaders, self.stream)
		self.stream.registerProducer(self, True)
		
	## FIXME: Actually processes Response, function is badly named!
	## FIXME: parent class needs to be patched for this.
	def processRequest(self):
		if self.request.responseReceived:
			self.request.responseReceived.callback(self)

	def submit(self):
		"""Submit a request, i.e. start writing it (reliably) to the server."""
		l = []
		request = self.request
		if request.method == "HEAD":
			# No incoming data will arrive.
			self.length = 0
		
		l.append('%s %s %s\r\n' % (request.method, request.uri,
								   self.outgoing_version))

		if request.stream is not None:
			if request.stream.length is not None and not request.chunkedOut:
				request.headers.setHeader('Content-Length', request.stream.length)
			else:
				# Got a stream with no length. Send as chunked and hope, against
				# the odds, that the server actually supports chunked uploads.
				request.headers.setHeader('Transfer-Encoding', ['chunked'])
				self.chunkedOut = True

		if request.headers is not None:
			for name, valuelist in request.headers.getAllRawHeaders():
				for value in valuelist:
					l.append("%s: %s\r\n" % (name, value))
		
		l.append("\r\n")
		self.transport.writeSequence(l)
	
		d = stream_mod.StreamProducer(request.stream).beginProducing(self)
		# When finished writing, call self._finish:
		d.addCallback(self._finish).addErrback(self._error)

	def write(self, data):
		"""Write some data to the server. Possibly will chunk this data."""
		if not data:
			return
		elif self.chunkedOut:
			self.transport.writeSequence(("%X\r\n" % len(data), data, "\r\n"))
		else:
			self.transport.write(data)

	def _finish(self, x):
		"""We are finished writing data."""
		if self.chunkedOut:
			# write last chunk and closing CRLF
			self.transport.write("0\r\n\r\n")
		
		self.finished = True
		self.channel.requestWriteFinished(self)
		del self.transport

	def _error(self, err):
		#XXX: what error code goes here?
		self._abortWithError(505,err)

	def _abortWithError(self, errcode, text):
		self.abortParse()
		e = ProtocolError(errcode,text)

		#print "Error!",e

		for d in (self.request.headersReceived,self.request.responseReceived,self.request.contentReceived):
			try:
				d.errback(e)
				break
			except defer.AlreadyCalledError,e: pass
		self.transport.loseConnection()
		#raise e # XXX Where does this go?

	def gotInitialLine(self, initialLine):
		"""The initial line from the server, i.e. HTTP/1.1 200 OK
		The rest of the lines are handled by the parent class
		"""
		parts = initialLine.split(' ', 2)
		
		# Parse the initial request line
		if len(parts) != 3:
			self._abortWithError(responsecode.BAD_REQUEST, 'Bad response line: %s' % initialLine)
			return

		strversion, self.code, message = parts
		
		try:
			protovers = http.parseVersion(strversion)
			if protovers[0] != 'http':
				raise ValueError()
		except ValueError:
			self._abortWithError(responsecode.BAD_REQUEST, "Unknown protocol: %s" % strversion)
			return
		
		self.version = protovers[1:3]

		# Ensure HTTP 0 or HTTP 1.
		if self.version[0] != 1:
			self._abortWithError(responsecode.HTTP_VERSION_NOT_SUPPORTED, 'Only HTTP 1.x is supported.')
			return

	def handleContentChunk(self, data):
		self.stream.write(data)

	def handleContentComplete(self):
		self.stream.finish()

class HTTPClientProtocol(basic.LineReceiver, policies.TimeoutMixin, object):
	"""A HTTP 1.1 Client with request pipelining support.
	This implements one "channel" on persistent connections.
	HTTPClientChannelRequest implements each request/response.

	http://www.w3.org/Protocols/rfc2616/rfc2616.html
	"""
	
	channel = HTTPClientChannelRequest 
	maxHeaderLength = 10240
	firstLine = True
	readPersistent=PERSIST_NO_PIPELINE
	
	# inputTimeOut should be pending whenever a complete request has
	# been written but the complete response has not yet been
	# received, and be reset every time data is received.
	inputTimeOut = 60 * 4

	def __init__(self):
		self.pipeline = []
		self.nextOne = OneTask()

	# The following functions field the data to the proper proto
	# The spec says:
	#	 A client that supports persistent connections MAY "pipeline" its
	#	requests (i.e., send multiple requests without waiting for each
	#	response). A server MUST send its responses to those requests in
	#	the same order that the requests were received.
	# So we can assume the responses will arrive in order, and that order
	# can only be guaranteed if the responses arrive on the same connection
	# so we can assume the responses will arrive on the same connection
	# as their request. Requests on different connections may have responses
	# out of the order the requests are sent, and that is a Good Thing.

	def lineLengthExceeded(self, line, wasFirst=False):
		code = wasFirst and responsecode.REQUEST_URI_TOO_LONG or responsecode.BAD_REQUEST
		self._abortWithError(code, "Header too long: %s %d" % (line[:100],len(line)))

	def lineReceived(self, line):
		if not self.curRequest():
			print "Extra line received?",line
			self.transport.loseConnection()
			return
		if len(line) > self.maxHeaderLength:
			self.lineLengthExceeded(line)
			self.transport.loseConnection()
			return
		if self.firstLine:
			self.firstLine = False
			self.curRequest().gotInitialLine(line)
		else:
			self.curRequest().lineReceived(line)

	def rawDataReceived(self, data):
		if not self.curRequest():
			print "Extra raw data!"
			# server sending random unrequested data.
			self.transport.loseConnection()
			return
		
		self.curRequest().rawDataReceived(data)
	
	def connectionMade(self):
		"""Prepare to send another request whenever a connection is newly made"""
		# Give a bit of time for other channels to pick up
		self.nextOne.run(self.sendAnother)

	def sendAnother(self):
		"""Send another request to the server
		The requests are stored in a pool on the Factory.
		Each connection protocol instance pulls from that pool here."""
		requests = self.factory.requests[(self.host,self.port)]
		if not requests:
			del self.factory.requests[(self.host,self.port)]
			if not self.pipeline:
				self.noMoreRequests()
			return

		if self.pipeline and not self.readPersistent:
			self._abortWithError(523,"Cannot send multiple requests on a non-persistent connection!")

		request = self.channel(
			self,
			requests.pop(0))

		self.pipeline.append(request)
#		print "Cur %d" % myid(self.curRequest())
		request.submit()

	def curRequest(self):
		if self.pipeline: return self.pipeline[0]

	def noMoreRequests(self):
		self.factory.channelDone(self)
		self.transport.loseConnection()
	
	# Note: for these two functions, if we are pipelining they call
	# sendAnother unconditionally. sendAnother will then call
	# noMoreRequests if necessary.

	def requestWriteFinished(self, request):
		"""Send another, if more requests can be submitted."""
		self.setTimeout(self.inputTimeOut)
		if self.readPersistent is PERSIST_PIPELINE:
			self.sendAnother()

	def requestReadFinished(self, request):
		"""Finished reading the response for a request.
		We can throw away the current request now, which will be 
		at the end of the pipeline."""

		assert self.curRequest() is request, "%s %d != %d" % (myid(self),myid(self.curRequest()),myid(request))
		
		self.firstLine = True
	
		self.pipeline.pop(0)
	
		if self.readPersistent:
			self.setTimeout(None)
			self.sendAnother()
		else:
			# No more requests, closing
			self.noMoreRequests()

	def setReadPersistent(self,rp):
		"""Set this to:
		False for no persistence
		PERSIST_NO_PIPELINE for persistence without pipelining
		PERSIST_PIPELINE for persitence and pipelining (default)
		Note: setting this can do nothing if your server doesn't 
		support the setting.
		"""
		self.readPersistent = rp

	def connectionLost(self, reason):
		self.readPersistent = False
		self.setTimeout(None)
		self.nextOne.cancel()
		if self.pipeline:
			# oops, some requests left unfinished
			# Try to return them to the factory's pool.
			# The current one may be partial content :/
			# If chunked, no it isn't since we can tell
			# 	when content has finished.
			# If content-length is specified, we can tell
			# 	if we've read that many bytes or not
			# 	(since self.length is decremented to 0)
			# If not finished writing, clearly this request
			# 	is incomplete and must be retried.
			# If parseCloseAsEnd is false, we're instructed
			#	not to parse the close as end, so don't.
			# If not chunked, no length, and finished writing
			#	and parseCloseAsEnd,
			#   we can't assume it hasn't finished, so finish it.

			current = self.pipeline[0]

			partialContent = True
			if current.finished:
				if not current.chunkedIn:
					if current.contentLength:
						if current.length > 0:
							partialContent = False
					elif current.parseCloseAsEnd:
						partialContent = False

			if not partialContent:
				# We're calling the current request complete
				# We do not have to save it in the factory then.
				rest = self.pipeline[1:]
			else:
				cur = self.pipeline[0]
				if cur.stream:
					cur.stream.finish(failure=reason)
				if cur.request.stream:
					try:
						# Unfortunately we can never resume the current request
						# Because the data stream cannot be reset or rewound
						# But one day hopefully...
						cur.request.stream.reset()
						rest = self.pipeline
					except AttributeError,e:
						rest = self.pipeline[1:]
				else:
					# But if there's no data, we can resume this request no problem
					rest = self.pipeline
			for chanreq in rest:
				self.factory.addRequest(chanreq.request)

class PipeSet(set):
	"""A set of pipes is odd... because each member of the set is a protocol
	instance, but we may promise to have that instance (by calling connectTCP)
	before we actually have it. So wantNum is how many pipes we "promise" will
	exist in the future. If it's too high, we defer the request until some
	other pipes request it, or finish.
	"""
	wantNum = 0

class HTTPClientFactory(protocol.ClientFactory):
	"""Connect to HTTP servers with pipelining and persistence.
	This factory cannot be called via reactor.connectTCP, since it
	may manage multiple connections at once. Instead pass the host, port
	and reactor as parameters to the constructor, set numPipes to how
	many connections you want, and call addRequest which will call
	connectTCP, if necessary.
	To connect to multiple host/ports, you have to make one factory per host.
	"""
	protocol = HTTPClientProtocol
	# How many pipes are we lining?
	maxPipesPerHost = 4 
	# Default connection policy if unspecified
	connectionPolicy = 'keep-alive'

	def __init__(self,reactor,requests=[]):
		self.pipes = defaultdict(PipeSet)
		self.requests = defaultdict(list)
		self.numRequests = 0
		self.reactor = reactor
		for request in requests:
			self.addRequest(request)
	def addRequest(self,request):
		"""Add one request to the pool.
		If we haven't maxxed out our pipelines for that host, connect to it 
		again. Otherwise wait for a connection to die in clientConnectionLost.
		"""
		host, port = request.host, request.port
		self.launchPipe(host,port)
		self.requests[(host,port)].append(request)
		self.numRequests += 1
	def launchPipe(self,host,port):
		who = self.pipes[host]
		if who.wantNum-1<self.maxPipesPerHost:
			who.wantNum += 1
			self.reactor.connectTCP(host,port,self)
	
	def buildProtocol(self,addr):
		"""Make sure we record this protocol instance, to manage max
		protocol/connections per host
		"""
		proto = protocol.ClientFactory.buildProtocol(self,addr)
		assert not hasattr(proto,'host')
		assert not hasattr(proto,'port')
		proto.host = addr.host
		proto.port = addr.port
		proto.factory = self
		self.pipes[addr.host].add(proto)
		return proto
	def channelDone(self, proto):
		"""When the client connection is lost, this is also called
		by the proto, because there's no way to figure out which
		protocol object lost the connection within clientConnectionLost.
		"""
		if not self.requests[(proto.host,proto.port)]:
			# We're winding down here
			who = self.pipes[proto.host]
			assert len(who)==who.wantNum,"We wanted %d but closed %d?" % (who.wantNum,len(who))
			who.discard(proto)
			who.wantNum -= 1
			if not who:
				del self.pipes[proto.host]
		
		self.numRequests -= 1

	def abort(self):
		"""Try to stop all connections, connection attempts, or queued connectionings."""
		for s in self.pipes:
			for proto in s:
				print "Huh?",proto
				proto.nextOne.cancel()
				proto.transport.loseConnection()
		self.pipes = defaultdict(set)
		self.requests = defaultdict(list)
	def clientConnectionLost(self,connector,reason):
		if not self.requests:
			# No more requests, don't try to connect again
			return
		for key in self.requests.keys():
			request = self.requests[key]
			if not request:
				del self.requests[key]
			else:
				host,port = key
				self.launchPipe(host,port)
				return

# As should be done, use client.http.Protocol, not HTTPClientProtocol
ChannelRequest = HTTPClientChannelRequest
Protocol = HTTPClientProtocol
Factory = HTTPClientFactory

#####################################################################
# To demonstrate, I'll make a little test server with some interesting
# resources on it. Since twisted.web2's server has pipelining and 
# persistence, we can fully exercise the use of this client class.
# A subprocess runs the server via twistd, while the main process
# connects to it. Change thePort to something unprivileged and 
# unused.

thePort = 10080

class TestRequestor(ChannelRequest):
	def processRequest(self):
		num = id(self) % 1024 # whatever
		def print_(n):
			print "DATA %s: %r" % (num, n)
		def printdone(n):
			print "DONE %s %s" % (num,self.request.uri)
		print "GOT RESPONSE %s: %s" % (num, self.code)
		return stream_mod.readStream(self.stream, print_).addCallback(printdone)

class TestProtocol(Protocol): 
	channel = TestRequestor

class TestFactory(Factory):
	protocol = TestProtocol
	numPipes = 3
	def channelDone(self, proto):
		Factory.channelDone(self,proto)
		if not len(self.pipes):
			# We're done
			reactor.stop()

def testConn(host):
	requests = (
		ClientRequest("GET", "/", {'Host':host},port=thePort),
		ClientRequest("GET", "/evil", {'Host':'foobar'},host=host,port=thePort),
		ClientRequest("GET", "/evil", host=host,port=thePort),
		ClientRequest("GET", "http://%s/foo/" % host,port=thePort),
		ClientRequest("GET", "/evil",host=host,port=thePort),
	)

	factory = TestFactory(reactor,requests)
	print "Client ready"

from twisted.web2 import server, http, resource, channel
import os,signal
import random

def testSrv():
	class Child(resource.Resource):
		addSlash = True
		def render(self, ctx):
			return http.Response(stream="Do what you want cause a pirate is free")

	class EvilChild(resource.Resource):
		addSlash = False
		def render(self, ctx):
			s=stream_mod.ProducerStream()
			s.write("Evil\r\n")
			s.write("Evil\r\n")
			self.evilrender(s,4)
			return http.Response(stream=s)
		def evilrender(self,s,count):
			if count <= 0:
				s.finish()
			else:
				s.write("Child\r\n")
				reactor.callLater(random.randrange(1,3),self.evilrender,s,count-1)


	class Toplevel(resource.Resource):
		child_foo = Child()
		child_evil = EvilChild()
		addSlash = True
		def render(self, ctx):
			return http.Response(stream="Hello synx!")

	site = server.Site(Toplevel())

	print "Starting server"
	reactor.listenTCP(thePort, channel.HTTPFactory(site))

if __name__=='__main__':
	#pid = subprocess.Popen(['twistd','-noy',sys.argv[0]])
	#time.sleep(1)
	testSrv()
	testConn('localhost')
	reactor.run()
