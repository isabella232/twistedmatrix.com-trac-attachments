from twisted.internet import reactor, task
from twisted.internet.protocol import Protocol, ClientFactory

class Counter:
    def __init__(self):
        self.count = 0

counter = Counter()

def add_connection():
    factory = ClientFactory()
    factory.protocol = Protocol
    reactor.connectTCP('localhost', 8007, factory)
    counter.count += 1

def print_count():
    print "Outgoing Connections: " + str(counter.count)
    
l = task.LoopingCall(add_connection)
l.start(0.1)

l = task.LoopingCall(print_count)
l.start(1)

reactor.run()
