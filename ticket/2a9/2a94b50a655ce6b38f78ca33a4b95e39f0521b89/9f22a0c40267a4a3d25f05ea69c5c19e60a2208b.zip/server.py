from twisted.internet import reactor, task
from twisted.internet.protocol import Factory, Protocol

class Counter:
    def __init__(self):
        self.count = 0

counter = Counter()

class SimpleProtocol(Protocol):
    def connectionMade(self):
        counter.count += 1
        print self

class SimpleFactory(Factory):
    protocol = SimpleProtocol

def print_count():
    print "Incoming Connections: " + str(counter.count)

l = task.LoopingCall(print_count)
l.start(1)

reactor.listenTCP(8007, SimpleFactory())
reactor.run()
