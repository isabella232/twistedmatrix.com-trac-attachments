#!/usr/bin/env python
#
# Using Curl and HTTP/1.1 works fine:
# curl -X GET -d foo http://user1:pass1@localhost:8080/mresource
#
# Curl and HTTP/1.1 with a bad password
# curl -X GET -d foo http://user1:badpass1@localhost:8080/mresource
#
# Simulation of a primitive HTTP/1.0 client with good credentials is ok.
#
#  nc localhost 8080 < get_good
#
# Simulation of a primitive HTTP/1.0 client causes Request.finish
# on a connection after it is lost.
#
#  nc localhosts 8080 < get_bad
#


# FYI:
#
# base64.encodestring("user1:pass1") => dXNlcjE6cGFzczE=
# base64.encodestring("user2:pass2") => dXNlcjI6cGFzczI=
#

import sys

from zope.interface import implements

from twisted.web import server, resource
from twisted.web.resource import IResource

from twisted.cred import checkers, credentials, error as credError
from twisted.web.guard import HTTPAuthSessionWrapper
from twisted.web.guard import BasicCredentialFactory
from twisted.cred.portal import IRealm, Portal
from twisted.internet import reactor, defer
from twisted.python import log

class SimpleHTTPRealm(object):
    implements(IRealm)

    def __init__(self, rootresource):
        self.rootresource = rootresource

    def requestAvatar(self, avatarId, mind, *interfaces):
        if IResource in interfaces:
            return (IResource, self.rootresource, lambda: None)
        raise NotImplementedError()

class MyResource(resource.Resource):

    def render_GET(self, request):
        data = request.content.read()
        print "render_GET path:%s got data:%s" % (request.path, data)
        return "All Ok"

class DeferringChecker(object):
    implements(checkers.ICredentialsChecker)
    credentialInterfaces = (credentials.IUsernamePassword,
                            credentials.IUsernameHashedPassword)

    def _successOrFailue(self, x):
        print "could not find user:%s" % x
        raise credError.UnauthorizedLogin("No Such User")

    def _timeConsumingOperation(self, user):
        print "looking up user:%s" % user
        d = defer.Deferred()
        reactor.callLater(1.0, d.callback, user)
        return d

    def requestAvatarId(self, credentials):
        print "requestAvatarId:%s" % credentials
        if credentials.username == "user1":
            if credentials.checkPassword("pass1"):
                return defer.succeed("user1")
            else:
                return defer.fail(credError.UnauthorizedLogin("Bad Password"))
        else:
            d = self._timeConsumingOperation(credentials.username)
            d.addCallback(self._successOrFailue)
            return d
            
    

def main():

    root = resource.Resource()

    m = MyResource()

    checker = DeferringChecker()

    m_portal = Portal(SimpleHTTPRealm(m), [checker])
    credentialFactory = BasicCredentialFactory("example")
    m_protected = HTTPAuthSessionWrapper(m_portal, [credentialFactory])
    root.putChild("mresource", m_protected)

    site = server.Site(root)
    reactor.listenTCP(8080, site)
    log.startLogging(sys.stdout)
    reactor.run()
    
    

if __name__ == "__main__":
    
    main()
