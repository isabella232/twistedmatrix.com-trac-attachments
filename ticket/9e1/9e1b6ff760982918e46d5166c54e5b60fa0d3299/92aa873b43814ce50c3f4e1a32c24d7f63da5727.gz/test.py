from twisted.web import static, server, twcgi
from twisted.internet import reactor

class PhpScript(twcgi.FilteredScript):
    filter = '/usr/bin/php-cgi'

resource = static.File('htdocs')
resource.processors = {".php": PhpScript}
resource.indexNames = ['index.php']

reactor.listenTCP(3000, server.Site(resource))
reactor.run()
