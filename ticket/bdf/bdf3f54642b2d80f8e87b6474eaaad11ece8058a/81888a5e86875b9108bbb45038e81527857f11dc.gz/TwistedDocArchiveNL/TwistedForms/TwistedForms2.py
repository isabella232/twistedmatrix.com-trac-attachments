#!/usr/bin/env python

from twisted.web import server, resource
from twisted.internet import reactor

class Simple(resource.Resource):
	isLeaf = True
	def render(self, request):
		"""
		request.args.get('key', '') gets the forms values.  This
		"page" just prints a SUBMIT button and a text field.

		There is no actual CGI called "default.cgi",  you would have
		to handle seperate script files manually at this stage,  but
		you could handle your forms page right here.  In this example
		I have a textfield called "Field" as you see in the HTML below.

		when submitting,  this just loops back to this code,  extracts
		the forms values,  then re-renders the forms page in html before 
		it exits and loops back again.
		"""
		IP = request.getClientIP()
		html = ""
		html += "<html>Hello, world!\n<br><br>\n"
		html += "Keys are...<br>\n"
		for key, value in request.args.items():
			html += "Key:%s - value: %s<br>\n" % (key, value)
		html += "<br>uri = %s<br>\n" % request.uri
		html += "<br>method = %s<br>\n" % request.method
		html += "<br>path = %s<br>\n" % request.path
		
		field_value = request.args.get('Field')
		html += "<br>Field = %s<br>\n" % field_value
		html += "<br>ClientIP = %s<br>\n" % IP
		button_val = request.args.get('submit')	
		html += "<br>button_val = %s<br>\n" % button_val
		form = """<FORM ACTION="/" METHOD="POST" ENCTYPE="application/x-www-form-urlencoded">
<P>Test input: <INPUT TYPE="TEXT" NAME="Field" SIZE="25"><BR>
<INPUT TYPE="SUBMIT" NAME="submit" VALUE="Submit">
</FORM>
</html>
"""
		return html + form

site = server.Site(Simple())
reactor.listenTCP(8080, site)
reactor.run()
