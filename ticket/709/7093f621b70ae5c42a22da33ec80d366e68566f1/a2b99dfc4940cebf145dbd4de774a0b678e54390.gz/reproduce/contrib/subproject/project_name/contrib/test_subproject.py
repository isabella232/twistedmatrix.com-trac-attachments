# Copyright (c) 2010-2011, Found IT A/S and Piped Project Contributors.
# See LICENSE for details.
from twisted.trial import unittest


class TestSomething(unittest.TestCase):

    def test_something(self):
        pass

