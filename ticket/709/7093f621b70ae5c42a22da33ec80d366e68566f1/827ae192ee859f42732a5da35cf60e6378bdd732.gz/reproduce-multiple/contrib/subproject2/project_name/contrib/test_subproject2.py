# Copyright (c) 2010-2011, Found IT A/S and Piped Project Contributors.
# See LICENSE for details.
from twisted.trial import unittest


class TestSomething2(unittest.TestCase):

    def test_something2(self):
        pass

