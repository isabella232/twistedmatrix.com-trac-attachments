# Copyright (c) 2010-2011, Found IT A/S and Piped Project Contributors.
# See LICENSE for details.
import os
import sys

from setuptools import setup, find_packages


packages = find_packages()

setup(
    name = 'project_name',
    license = 'BSD',

    author = 'None',

    packages = packages,
    namespace_packages = ['project_name', 'project_name.contrib'],
)
