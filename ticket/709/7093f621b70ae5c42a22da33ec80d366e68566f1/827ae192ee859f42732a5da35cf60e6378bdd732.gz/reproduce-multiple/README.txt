# create the .egg-info directory
python setup.py develop

# configure sys.path to include the master project, and a contrib sub-project
export PYTHONPATH=.:contrib/subproject:contrib/subproject2

# run trial
trial project_name

# expected results: 1 unit test being run.
