# Do everything
from twisted.application import internet, service
from finger19_libserv import FingerService
from finger19_libprot import FingerProtocol, FingerFactoryFromService
from finger19_libirc import IRCReplyBot, IRCClientFactoryFromService
from finger19_libweb import UserStatusTree, UserStatus, UserStatusXR

application = service.Application('finger', uid=1, gid=1)
fingerService = FingerService('/etc/users')
serviceCollection = service.IServiceCollection(application)

fingerFactory = FingerFactoryFromService(fingerService)
fingerServer = internet.TCPServer(79, fingerFactory)
fingerServer.setServiceParent(serviceCollection)

httpFactory = UserStatusTree(fingerService)
webServer = internet.TCPServer(8000, server.Site(httpFactory))
webServer.setServiceParent(serviceCollection)

ircFactory = IRCClientFactoryFromService(fingerService)
ircClient = internet.TCPClient('irc.freenode.org', 6667, ircFactory)
ircClient.setServiceParent(serviceCollection)
