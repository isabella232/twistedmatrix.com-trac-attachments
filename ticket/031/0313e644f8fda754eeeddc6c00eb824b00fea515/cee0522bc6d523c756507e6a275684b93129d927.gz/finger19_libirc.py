# IRCBot component
from twisted.words.protocols import irc
from finger19_liberr import catchError

class IRCReplyBot(irc.IRCClient):

    def connectionMade(self):
        self.nickname = self.factory.nickname
        irc.IRCClient.connectionMade(self)

    def privmsg(self, user, channel, msg):
        user = user.split('!')[0]
        if self.nickname.lower() == channel.lower():
            d = self.factory.getUser(msg)
            d.addErrback(catchError)
            d.addCallback(lambda m: "Status of %s: %s" % (msg, m))
            d.addCallback(lambda m: self.msg(user, m))


class IRCClientFactoryFromService(protocol.ClientFactory):
    """@ivar nickname"""
    
    protocol = IRCReplyBot
    nickname = 'fingerbot'

    def __init__(self, service):
        self.service = service

    def getUser(self, user):
        """Return a deferred returning a string"""
        return self.service.getUser(user)


if name == '__main__':
    from twisted.application import internet, service
    from finger19_libserv import FingerService

    application = service.Application('finger', uid=1, gid=1)
    fingerService = FingerService('/etc/users')
    serviceCollection = service.IServiceCollection(application)

    ircFactory = IRCClientFactoryFromService(fingerService)
    ircClient = internet.TCPClient('irc.freenode.org', 6667, ircFactory)
    ircClient.setServiceParent(serviceCollection)
