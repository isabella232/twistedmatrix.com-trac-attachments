# Finger error report

def catchError(err):
    return "Internal error in server"
