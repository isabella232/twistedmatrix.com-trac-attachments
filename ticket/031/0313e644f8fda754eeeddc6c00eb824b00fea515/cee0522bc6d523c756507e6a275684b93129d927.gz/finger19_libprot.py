# FingerProtocol component
from twisted.protocols import basic
from finger19_liberr import catchError

class FingerProtocol(basic.LineReceiver):

    def lineReceived(self, user):
        d = self.factory.getUser(user)
        d.addErrback(catchError)
        def writeValue(value):
            self.transport.write(value+'\r\n')
            self.transport.loseConnection()
        d.addCallback(writeValue)


class FingerFactoryFromService(protocol.ServerFactory):

    protocol = FingerProtocol

    def __init__(self, service):
        self.service = service

    def getUser(self, user):
        """Return a deferred returning a string"""
        return self.service.getUser(user)


if name == '__main__':
    from twisted.application import internet, service
    from finger19_libserv import FingerService

    application = service.Application('finger', uid=1, gid=1)
    fingerService = FingerService('/etc/users')
    serviceCollection = service.IServiceCollection(application)

    fingerFactory = FingerFactoryFromService(fingerService)
    fingerServer = internet.TCPServer(79, fingerFactory)
    fingerServer.setServiceParent(serviceCollection)
