# FingerService component
from twisted.internet import protocol, reactor, defer

class FingerService(service.Service):

    def __init__(self, filename):
        self.filename = filename
        self._read()

    def _read(self):
        self.users = {}
        for line in file(self.filename):
            user, status = line.split(':', 1)
            user = user.strip()
            status = status.strip()
            self.users[user] = status
        self.call = reactor.callLater(30, self._read)

    def getUser(self, user):
        """Return a deferred returning a string"""
        return defer.succeed(self.users.get(user, "No such user"))

    def getUsers(self):
        """Return a deferred returning a list of strings"""
        return defer.succeed(self.users.keys())


if name == '__main__':
    from twisted.application import internet, service
    from finger19_libprot import FingerProtocol, FingerFactoryFromService

    application = service.Application('finger', uid=1, gid=1)
    fingerService = FingerService('/etc/users')
    serviceCollection = service.IServiceCollection(application)

    fingerFactory = FingerFactoryFromService(fingerService)
    fingerServer = internet.TCPServer(79, fingerFactory)
    fingerServer.setServiceParent(serviceCollection)
