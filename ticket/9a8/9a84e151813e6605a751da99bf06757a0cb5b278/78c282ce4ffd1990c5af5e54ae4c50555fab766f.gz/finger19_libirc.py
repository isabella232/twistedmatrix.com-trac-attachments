class IIRCClientFactory(Interface):

    def getUser(user):
        """
        Return a deferred returning a string
        """

class IRCClientFactoryFromService(protocol.ClientFactory):

    implements(IIRCClientFactory)

    protocol = IRCReplyBot
    nickname = None

    def __init__(self, service):
        self.service = service

    def getUser(self, user):
        return self.service.getUser(user)

components.registerAdapter(IRCClientFactoryFromService,
                           IFingerService,
                           IIRCClientFactory)

if name == '__main__':
    application = service.Application('finger', uid=1, gid=1)
    f = FingerService('/etc/users')
    i = IIRCClientFactory(f)
    i.nickname = 'fingerbot'
    internet.TCPClient('irc.freenode.org', 6667, i  
                       ).setServiceParent(serviceCollection)
