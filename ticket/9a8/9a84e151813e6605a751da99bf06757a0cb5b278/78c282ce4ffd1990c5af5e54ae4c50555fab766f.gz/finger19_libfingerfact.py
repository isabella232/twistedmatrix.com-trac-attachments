class FingerFactoryFromService(protocol.ServerFactory):

    implements(IFingerFactory)

    protocol = FingerProtocol

        def __init__(self, service):
            self.service = service

        def getUser(self, user):
            return self.service.getUser(user)

components.registerAdapter(FingerFactoryFromService,
                           IFingerService,
                           IFingerFactory)

if name == '__main__':
    application = service.Application('finger', uid=1, gid=1)
    f = FingerService('/etc/users')
    internet.TCPServer(79, IFingerFactory(f)
                       ).setServiceParent(serviceCollection)