class IFingerService(Interface):
    def getUser(user):
        """Return a deferred returning a string."""

    def getUsers():
        """Return a deferred returning a list of strings."""

class IFingerFactory(Interface):
    def getUser(user):
        """Return a deferred returning a string."""

class FingerService(service.Service):

    implements(IFingerService)

    def __init__(self, filename):
        self.filename = filename
        self._read()

    def _read(self):
        self.users = {}
        for line in file(self.filename):
            user, status = line.split(':', 1)
            user = user.strip()
            status = status.strip()
            self.users[user] = status
        self.call = reactor.callLater(30, self._read)

    def getUser(self, user):
        return defer.succeed(self.users.get(user, "No such user"))

    def getUsers(self):
        return defer.succeed(self.users.keys())

if __name__ == '__main__':
    application = service.Application('finger', uid=1, gid=1)
    f = FingerService('/etc/users')
    serviceCollection = service.IServiceCollection(application)
