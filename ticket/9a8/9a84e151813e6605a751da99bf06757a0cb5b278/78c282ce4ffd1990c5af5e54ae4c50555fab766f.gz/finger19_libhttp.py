class HTTPFactoryFromService(resource.Resource):

    implements(resource.IResource)

    def __init__(self, service):
        resource.Resource.__init__(self)
        self.service = service
        self.putChild('RPC2', UserStatusXR(self.service))

    def render_GET(self, request):
        d = self.service.getUsers()
        def formatUsers(users):
            l = ['&lt;li&gt;&lt;a href="%s"&gt;%s&lt;/a&gt;&lt;/li&gt;' % (user, user)
                 for user in users]
            return '&lt;ul&gt;'+''.join(l)+'&lt;/ul&gt;'
        d.addCallback(formatUsers)
        d.addCallback(request.write)
        d.addCallback(lambda _: request.finish())
        return server.NOT_DONE_YET

    def getChild(self, path, request):
        if path=="":
            return HTTPFactoryFromService(self.service)
        else:
            return UserStatus(path, self.service)

components.registerAdapter(HTTPFactoryFromService,
                           IFingerService,
                           resource.IResource)

if name == '__main__':
    application = service.Application('finger', uid=1, gid=1)
    f = FingerService('/etc/users')
    internet.TCPServer(8000, server.Site(resource.IResource(f))
                       ).setServiceParent(serviceCollection)

