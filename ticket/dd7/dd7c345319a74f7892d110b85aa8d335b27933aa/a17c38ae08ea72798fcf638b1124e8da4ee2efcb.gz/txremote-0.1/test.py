#!/usr/bin/python

from zope.interface import Interface, Attribute, implements

from twisted.python import components
from twisted.cred import portal, checkers, credentials
from twisted.web import resource, server
from twisted.python import log

from twisted.application import service, internet

from txremote import xremote

class IUser(Interface):
    username = Attribute('the username')

class User:
    implements(IUser)
    def __init__(self, username):
        self.username = username
    def logout(self, *p):
        pass

class Page(resource.Resource):
    def render_GET(self, request):
        return '''<html><body>Welcome %s</body></html>''' % (self.original.username,)

def user2page(user):
    p = Page()
    p.original = user
    return p

components.registerAdapter(user2page, IUser, resource.IResource)

class SimpleRealm:
    implements(portal.IRealm)

    def requestAvatar(self, avatarId, mind, *interfaces):
        avatar = User(avatarId)
        for iface in interfaces:
            log.msg('interface', iface, 'for', avatarId, avatar)
            adapted = iface(avatar)
            if not adapted is None:
                return (iface, adapted, avatar.logout)

        raise NotImplementedError('cant support that interface')

realm = SimpleRealm()
check = xremote.TrustedUserChecker()

portl = portal.Portal(realm, [check])

res = xremote.RemoteUserSessionWrapper(portl)

site = server.Site(res)

application = service.Application('test')
web = internet.TCPServer(8081, site)
web.setServiceParent(application)

# Now add the following to Apache
#
# RewriteEngine   on
# RewriteRule     /foo(.*) http://localhost:8081/$1 [L,P]
#
# <Location /foo>
#   # Setup apache auth e.g. mod_auth_kerb
#
#   require valid-user
#
#   RewriteEngine     on
#   RewriteCond       %{REMOTE_USER} (.*)
#   RewriteRule       .* - [E=RU:%1]
#
#   RequestHeader     set X-Remote-User %{RU}e
#   RequestHeader     unset Authorization
# </Location>
