# -*- test-case-name: txremote.test.test_x_remote

from zope.interface import implements, Attribute

from twisted.cred import credentials, checkers
from twisted.web.resource import IResource
from twisted.web.error import ErrorPage
from twisted.web import util
from twisted.python.components import proxyForInterface
from twisted.python import log

import re

class ITrustedUsername(credentials.ICredentials):
    username = Attribute('username')

class TrustedUsername:
    implements(ITrustedUsername)

    def __init__(self, valuedict):
        self.h = valuedict

class TrustedUserChecker:
    implements(checkers.ICredentialsChecker)

    credentialInterfaces = (ITrustedUsername,)

    def requestAvatarId(self, credentials):
        return credentials.h['username']

class RemoteUserSessionWrapper:
    isLeaf = False

    def __init__(self, portal, header='X-Remote-User', body='(?P<username>.*)'):
        self.header = header
        self.portal = portal
        self.re = re.compile(body)

    def render(self, request):
        raise NotImplementedError

    def getChildWithDefault(self, path, request):
        auth = request.getHeader(self.header)
        if not auth:
            # raising a 401 is not valid, it'll confuse the browser
            # since apache is handling the auth challenges
            log.err('missing remote user header')
            return ErrorPage(403, None, None)

        m = self.re.match(auth)
        if not m:
            log.err('invalid remote user header')
            return ErrorPage(403, None, None)

        log.msg('got', self.header, m.groupdict())

        creds = TrustedUsername(m.groupdict())

        d = self.portal.login(creds, None, IResource)
        d.addCallbacks(self._loginok, self._loginbad)
        return util.DeferredResource(d)

    def _loginok(self, (interface, avatar, logout)):
        # FIXME: this is common with HTTPAuthSessionWrapper, should
        # be in a common base class or similar
        class ResourceWrapper(proxyForInterface(IResource, 'resource')):
            def getChildWithDefault(self, path, request):
                return ResourceWrapper(self.resource.getChildWithDefault(path, request))
            def render(self, request):
                request.notifyFinish().addCallback(lambda ign: logout())
                return super(ResourceWrapper, self).render(request)

        return ResourceWrapper(avatar)

    def _loginbad(self, result):
        # again, returning a 401 is bad
        log.err(result)
        return ErrorPage(403, None, None)


