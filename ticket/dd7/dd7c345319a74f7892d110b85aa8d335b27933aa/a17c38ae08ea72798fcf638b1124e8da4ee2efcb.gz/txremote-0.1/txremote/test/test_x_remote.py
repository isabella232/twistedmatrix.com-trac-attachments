
from zope.interface import implements

from twisted.trial import unittest
from twisted.cred import portal
from twisted.web.server import NOT_DONE_YET
from twisted.web.resource import Resource, IResource
from twisted.web.static import Data

from twisted.web.test.test_web import DummyRequest

from txremote import xremote

# simple realm gets avatar from the testcase
class Realm:

    implements(portal.IRealm)

    def __init__(self, getter):
        self.getter = getter

    def requestAvatar(self, avatarId, mind, *interfaces):
        if IResource in interfaces:
            return IResource, self.getter(avatarId), self.logout

    def logout(self):
        pass


def render(resource, request):
    res = resource.render(request)
    if res is NOT_DONE_YET:
        return
    request.write(res)
    request.finish()

class XRemoteTests(unittest.TestCase):

    makeRequest = DummyRequest

    headerName = 'X-SomeRemoteUser'

    def setUp(self):
        # FIXME: lots of this code seems common to twisted.web.test.test_httpauth
        self.username = 'aUser'
        self.childName = 'foo'
        self.childData = 'bar'

        self.avatar = Resource()
        self.avatar.putChild(
                self.childName,
                Data(self.childData, 'text/plain'),
                )

        self.avatars = {self.username: self.avatar}

        self.checker = xremote.TrustedUserChecker()
        self.realm = Realm(self.avatars.get)
        self.portal = portal.Portal(self.realm, [self.checker])
        self.wrapper = xremote.RemoteUserSessionWrapper(self.portal, self.headerName)

    def testLoginOk(self):
        rq = self.makeRequest([self.childName])
        # header names need to be lower-cased when fiddling the DummyRequest
        # 'headers' dict by hand, which is confusing until you figure it out
        rq.headers[self.headerName.lower()] = self.username

        child = self.wrapper.getChildWithDefault(self.childName, rq)

        def cb(ignored):
            self.assertEquals(rq.written, [self.childData])

        d = rq.notifyFinish()
        d.addCallback(cb)

        render(child, rq)

        return d

    def testLoginBad(self):
        rq = self.makeRequest([self.childName])
        child = self.wrapper.getChildWithDefault(self.childName, rq)

        render(child, rq)

        self.assertEqual(rq.responseCode, 403)
