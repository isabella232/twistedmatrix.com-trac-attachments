from twisted.application import service, internet
from twisted.internet import protocol, reactor
from twisted.web import static,server,script,resource

UID = 1000
GID = 1000


root = static.File("./root")

root.indexNames=['index.rpy']
root.processors = {'.rpy': script.ResourceScript}
root.ignoreExt(".rpy")

ws = internet.TCPServer(8080, server.Site(root))
application = service.Application('Web Server', uid=UID, gid=GID)
ws.setServiceParent(application)
