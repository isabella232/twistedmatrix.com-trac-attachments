# from BTL import reactor_magic

ADDR = '127.0.0.1'
PORT1 = 8023
PORT2 = 8024

import os
from SimpleXMLRPCServer import SimpleXMLRPCServer
import threading
import time
import xmlrpclib

from twisted.internet import iocpreactor
iocpreactor.proactor.install()

from twisted.web.xmlrpc import Proxy
from twisted.internet import reactor

def run_django(): 
    """Run the Django server in the background."""
    os.environ['DJANGO_SETTINGS_MODULE'] = 'done.settings'
    from django.core.management.commands.runserver import Command
    runserver = Command()
    handle = lambda: runserver.handle( 
              addrport = "%s:%d" % (ADDR, PORT1), 
              use_reloader = False)
    thread = threading.Thread(name = "Django server", 
                              target = handle)
    thread.setDaemon(True)
    thread.start()
    print "Sleeping 3s to give Django time to start..."
    time.sleep(3)

def run_xmlrpc(): 
    """Run the default XML-RPC server."""
    server = SimpleXMLRPCServer((ADDR, PORT2))
    server.register_function(lambda x: x, 'Echo')
    thread = threading.Thread(name = "XML-RPC server", 
                              target = server.serve_forever)
    thread.setDaemon(True)
    thread.start()

def runtest(name, rpc2_url): 
    print '-' * 75
    print "Testing Python client to %s (%s)..." % (name, rpc2_url)
    s = xmlrpclib.Server(rpc2_url)
    print "=> %s" % repr(s.Echo('kjhds'))

    print '-' * 75
    print "Testing Twisted client to %s (%s)..." % (name, rpc2_url)
    def printValue(value):
        print "=> %s" % repr(value)
        reactor.stop()

    proxy = Proxy(rpc2_url)
    proxy.callRemote('Echo', 'kjhds').addCallbacks(printValue, printValue)
    reactor.run()

if __name__ == '__main__': 
    run_django()
    run_xmlrpc()
    runtest("SimpleXMLRPCServer", 'http://%s:%d/' % (ADDR, PORT2))
    runtest("Django", 'http://%s:%d/RPC2/' % (ADDR, PORT1))
    print "All tests done."

