from django.conf.urls.defaults import *
from done.views import handle_xmlrpc

urlpatterns = patterns('',
    (r'^RPC2/$', handle_xmlrpc)
)

