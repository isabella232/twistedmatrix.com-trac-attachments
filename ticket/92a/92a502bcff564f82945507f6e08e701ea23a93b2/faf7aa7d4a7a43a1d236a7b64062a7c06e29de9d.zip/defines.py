#!/usr/bin/env python
# -*- coding: iso-8859-15 -*-#
#-----------------------------------------------------------------------------
# Name:        defines.py
# Purpose:     Global definitions of project.
#
# Author:      Licia Leanza
#
# Created:     2007/05/21
# RCS-ID:      $Id: defines.py 3 2008-05-22 15:34:14Z licia $
# Copyright:   (c) Licia Leanza: 2006-2008
# Licence:     LGPL
# Package:     twlogging
#-----------------------------------------------------------------------------
"""
Module defining common data to be used by all modules.
"""

__version__ = "$Rev: 3 $"
__docformat__ = "epytext en"

import os.path

# log-server data files configuration parameters
_hwd = os.path.expanduser("~")
LOG_DATA_DIR =  os.path.join(_hwd, 'TWLogging') 
"""default log files directory = ~/TWlogging"""
try:
    os.mkdir(LOG_DATA_DIR)
except: pass
LOG_SRV_DATA_FILE_C =  'TWLogging-C.log'
"""default log-server's centralized log file name in circular mode"""
LOG_SRV_DATA_FILE_D =  'TWLogging-D.log'
"""default log-server's centralized log file name in daily mode"""
LOG_FILE_MAX_BYTES = 2*1000*1000 
"""default log-server's centralized circular log file max dimension"""
LOG_FILE_BACKUP_COUNT = 31
"""default log-server's centralized log files number"""

def CircularFile():
    """
    Main task of a log-server is to do a centralized storaging of all I{log 
    messages}. 
    
    To do this it can use a circular file facility of a given `name` 
    L{LOG_SRV_DATA_FILE_C}, a given `size` L{LOG_FILE_MAX_BYTES}, 
    with a given `number` L{LOG_FILE_BACKUP_COUNT} of backup copies
    
    """
    ffilename = fullfilename[CircularFile]
    import twlogging
    obs = twlogging.TwLogging('LSS',level=twlogging.TRACE,bIndependent=True,
        fmt = twlogging.STORAGE_FORMATTER, handlerId =twlogging.AppCircFile, 
        filename = ffilename, maxBytes = LOG_FILE_MAX_BYTES,
        backupCount = LOG_FILE_BACKUP_COUNT, encoding = 'utf-8')
    return obs.logger

def DailyFile():
    """
    Main task of a log-server is to do a centralized storaging of all I{log 
    messages}. 
    
    To do this it can use a daily file of a given `name` 
    L{LOG_SRV_DATA_FILE_D}, that will be closed on midnight, 
    with a given `number` L{LOG_FILE_BACKUP_COUNT} of backup copies
    
    """
    ffilename = fullfilename[DailyFile]
    import twlogging
    obs = twlogging.TwLogging('LSS',level=twlogging.TRACE,bIndependent=True,
        fmt = twlogging.STORAGE_FORMATTER, handlerId =twlogging.AppDailyFile, 
        filename = ffilename, when='midnight', 
        backupCount = LOG_FILE_BACKUP_COUNT, encoding = 'utf-8')
    return obs.logger

# preferred storage mode for log-server data files
LOG_SRV_DATA_LOGGER = CircularFile
"""default log-server's centralized log file type = CircularFile. You can change
it here uncommenting the DailyFile assignment"""
##LOG_SRV_DATA_LOGGER = DailyFile

# log-server connection data
LOCAL_HOST = '127.0.0.1'
TWLOGGING_PORT = 23232
"""default log-server's connection port"""

fullfilename =  {CircularFile:  os.path.join(LOG_DATA_DIR, LOG_SRV_DATA_FILE_C),
                 DailyFile:     os.path.join(LOG_DATA_DIR, LOG_SRV_DATA_FILE_D),
                }