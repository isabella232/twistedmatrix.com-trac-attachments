#-----------------------------------------------------------------------------
# Name:        test_twl.py
# Purpose:     
#
# Author:      Licia Leanza
#
# Created:     2008/05/20
# RCS-ID:      $Id: test_twl.py 3 2008-05-22 15:34:14Z licia $
# Copyright:   (c) 2008
# Licence:     LGPL v2
# Email:       guarda.sw@gmail.com
# Package:     twlogging
#-----------------------------------------------------------------------------
"""
Unitest Module for L{twnetlog} and L{twlogging}
"""

__version__ = "$Rev: 3 $"
__docformat__ = "epytext en"


import codecs, os

import defines
TWL_MESSAGE = '.............twlogging message..............'
TWL_LOGGER = 'TEST'
logfile = 'LOG_SRV_DATA_FILE.test'
defines.fullfilename[defines.LOG_SRV_DATA_LOGGER] = logfile
try:    os.remove(logfile)
except: pass

import twlogging
logger = twlogging.getLogger(TWL_LOGGER,level=twlogging.CRITICAL)
logger.err = logger.error
import twnetlog

from twisted.trial import unittest


from twisted.internet import defer, reactor

def deferLater(n, callable, *args):
    """
    Return a L{defer.Deferred} that will fire in C{n} seconds.
    """
    d = defer.Deferred()
    d.addCallback(callable)
    reactor.callLater(n, d.callback, args)
    return d


class LoggerTest(unittest.TestCase):

    def setUp(self):
        self.server = twnetlog.startLogSever()
        logger.observer.addHdlrWfmt(twlogging.AppSrv,twlogging.DEFAULT_FORMATTER, 
                            twlogging.DEFAULT_LEVEL, host=defines.LOCAL_HOST)
        
    def tearDown(self):
        twlogging.removeHandlerFromLoggers(twlogging.AppSrv)
        self.server.stop()

    def testBaseLog(self):
        """This message will be logged onto the server's file"""
        loggerBASE = twlogging.getLogger('BASE',level=twlogging.TRACE)
        self.testlogger = loggerBASE.info
        return deferLater(.1, self._sendmsg, TWL_MESSAGE, True)

    def testUpLevelLog(self):
        """This message will _not_ be logged onto the server's file because its 
        level is minor than the logger's level"""
        loggerUP = twlogging.getLogger('UP',level=twlogging.ERROR)
        self.testlogger = loggerUP.info
        return deferLater(.1, self._sendmsg, TWL_MESSAGE, False)

    def testFilterLog(self):
        """This message will be logged onto the server's file because the filter
        it's equal to its name"""
        loggerFILTER = twlogging.getLogger('FILTER',level=twlogging.TRACE)
        loggerFILTER.observer.setFilter(twlogging.AppSrv, TWL_LOGGER+'.FILTER')
        self.testlogger = loggerFILTER.info
        return deferLater(.1, self._sendmsg, TWL_MESSAGE, True)

    def testPassLog(self):
        """This message will be logged onto the server's file because the filter
        is not set."""
        loggerPASS = twlogging.getLogger('PASS',level=twlogging.TRACE)
        loggerPASS.observer.setFilter(twlogging.AppSrv, '')
        self.testlogger = loggerPASS.info
        return deferLater(.1, self._sendmsg, TWL_MESSAGE, True)

    def testNoFilterLog(self):
        """This message will _not_ be logged onto the server's file because the
        filter is set to something else."""
        loggerFILTER = twlogging.getLogger('noFILTER',level=twlogging.TRACE)
        loggerFILTER.observer.setFilter(twlogging.AppSrv, TWL_LOGGER+'.OTHER')
        self.testlogger = loggerFILTER.info
        return deferLater(.1, self._sendmsg, TWL_MESSAGE, False)

    def _sendmsg(self,(msg, bPresence)):
        self.testlogger(msg)
        return deferLater(.1, self._failed, msg, bPresence) 
    def _failed(self, (msg, bPresence)): 
        f = codecs.open(logfile, "r", "UTF8")
        self.lines = f.readlines()
        f.close()
        if bPresence:
            self.failUnless(self.lines[-2].find(msg) != -1)
        else:
            self.failIf(self.lines[-2].find(msg) != -1)
