#!/usr/bin/env python
# -*- coding: utf-8 -*-#
# -*- test-case-name: .test.test_twlogging.py -*-
#-------------------------------------------------------------------------------
# Name:        twlogging.py
# Purpose:     Implements a Python's logging logger as a Twisted observer.
#
# Author:      Licia Leanza
# E-mail:      guarda.sw@gmail.com
#
# Created:     09-03-08
# RCS-ID:      $Id: twlogging.py 3 2008-05-22 15:34:14Z licia $
# Copyright:   (c) Licia Leanza: 2006-2008
# Licence:     LGPL 
# Package:     twlogging
#-----------------------------------------------------------------------------
"""
This implements the main classes of B{I{twlogging system}}.

This module will be imported in a twisted application, instead of python 
standard logging module, if the application wants to use I{python logging } 
functions integrated in I{twisted log}.

Twisted application, that wants to use twlogging system, can symply get its 
I{python loggers} from an almost usual L{twlogging.getLogger}('logger.name').
This automatically instantiates a L{TwLogging} object that is a 
L{PythonLoggingObserver} which implements the link between I{twisted log} and 
I{python logging }services. 

After that, the application will associate all desidered handlers to its logger.
Any subsequent logger will generate its name appending its id to the first 
logger's name. It will also inherit all its handlers with their formatter 
and severity level. 

Not all python logging handler are allowed to be used with PythonLoggingObserver
Tipically SocketHandler can't be used in a twisted application. 
Only L{__ALLOWED_HANDLERS} can be used.

G{classtree TwLogging, NetworkClientHandler, QtWidgetHandler}
"""

__version__ = "$Rev: 3 $"
__docformat__ = "epytext en"

import time
from datetime import datetime
import logging

import sys, os, string, types



try:
    PythonLoggingObserver_Instanziato
except:
    PythonLoggingObserver_Instanziato = False


# I substitute and add some methods to logging.Logger

def addMethodToClass(func, clas, method_name=None):
    """It adds the given function to a certain class naming it, by default, with 
    the same function name.
    """
    import new
    method = new.instancemethod(func, None, clas)
    if not method_name: method_name=func.__name__
    setattr(clas,method_name,method)


if hasattr(sys, 'frozen'): #support for py2exe
#    __srcfile = "logging%s__init__%s" % (os.sep, __file__[-4:])
    __srcfile = "twlogging%s__init__%s" % (os.sep, __file__[-4:])
elif string.lower(__file__[-4:]) in ['.pyc', '.pyo']:
    __srcfile = __file__[:-4] + '.py'
else:
    __srcfile = __file__
from twisted.python import log
__logfile = log.__file__
if hasattr(sys, 'frozen'): #support for py2exe
    __logfile = os.path.join("twisted", "python", __logfile[-4:])
    print 'py2exe: __logfile=',__logfile
elif string.lower(__logfile[-4:]) in ['.pyc', '.pyo']:
    __logfile = __logfile[:-4] + '.py'
else:
    __logfile = __logfile
__srcfile = os.path.normcase(__srcfile)
__logfile = os.path.normcase(__logfile)

def findCaller(self):
    """
    The usual logger's findCaller doen't work any more due to 
    L{twisted.python.log} intermediate module inserted before the real call to 
    logger.
    So this modifyed function will substitue the original one.
    """
    f = logging.currentframe().f_back
    rv = "(unknown file)", 0, "(unknown function)"
    while hasattr(f, "f_code"):
        co = f.f_code
        filename = os.path.normcase(co.co_filename)
        if filename in (__srcfile, __logfile):    # <twlogging> or <log> module
            f = f.f_back
            continue
        rv = (filename, f.f_lineno, co.co_name)
        break
    return rv

addMethodToClass(findCaller,logging.Logger)



from logging import CRITICAL, FATAL, ERROR, WARNING, WARN, INFO, DEBUG, NOTSET
TRACE = logging.DEBUG -1
"""This is a new logging level. A very verbose one."""
logging.TRACE = TRACE 
logging._levelNames [logging.TRACE]= 'TRACE'
logging._levelNames ['TRACE']= logging.TRACE

def trace(self, msg, *args, **kwargs):
    """
    Log 'msg % args' with severity 'TRACE'.
    
    This new way to emit logging messages will be added to the original ones.
    """
    if self.manager.disable >= TRACE:
        return
    if self.isEnabledFor(TRACE):
        apply(self._log, (TRACE, msg, args), kwargs)

addMethodToClass(trace,logging.Logger)


def getMessage(self):
    """
    Return the message for this LogRecord.

    Return the message for this LogRecord after merging any user-supplied
    arguments with the message.
    I had problems with unicode log messages. This seems to solve them, so I 
    substitute this function too.
    """
    if not hasattr(types, "UnicodeType"): #if no unicode support...
        msg = str(self.msg)
    else:
        msg = self.msg
        if type(msg) not in (types.UnicodeType, types.StringType):
            try:
                msg = str(self.msg)
            except UnicodeError:
                msg = self.msg      #Defer encoding till later
    if self.args:
        msg = msg % self.args
    if type(msg) == types.UnicodeType :
        return msg
    else:
        return msg.decode('utf_8','replace')

addMethodToClass(getMessage,logging.LogRecord)


import twnetlog

class NetworkClientHandler(object,logging.Handler):
    """
    A handler class which writes logging records, appropriately formatted,
    into a twisted client-server connection towards the log-server. 
    """

    _singletons = {}
    def __new__(cls, *args, **kwds):
        if cls not in cls._singletons:
            cls._singletons[cls] = object.__new__(cls)
        return cls._singletons[cls]

    def __init__(self, host):
        """It starts a log-client that will send all the emmitted messeges to 
        the log-server resident on the given host.
        """
        logging.Handler.__init__(self)
        self.setLevel(TRACE)
        self.formatter = NETWORK_FORMATTER
        self.logClient = twnetlog.startLogClient(host, 
                                                 oncmd = self.OnCommandReceived)

    def flush(self):
        """
        Flushes the stream.
        """
        pass

    def emit(self, record):
        """
        Emit a record.

        If a formatter is specified, it is used to format the record.
        The record is then written to the stream with a trailing newline
        [N.B. this may be removed depending on feedback]. If exception
        information is present, it is formatted using
        traceback.print_exception and appended to the stream.
        """
        self.formatter = NETWORK_FORMATTER  # always this formatter!!!
        try:
            msg = self.format(record)
            fs = "%s\n"
            if not hasattr(types, "UnicodeType"): #if no unicode support...
                self.logClient.sendLogMsg(fs % msg)
            else:
                try:
                    self.logClient.sendLogMsg(fs % msg)
                except UnicodeError:
                    self.logClient.sendLogMsg(fs % msg.encode('utf-8','replace'))
            self.flush()
        except (KeyboardInterrupt, SystemExit):
            raise
        except:
            self.handleError(record)

    def close(self):
            """
            Closes the connection.
            """
            self.logClient.stop()
            
    def OnCommandReceived(self, cmd, rec):
        self.execReceivedCommand( cmd, rec)
    def execReceivedCommand( cmd, rec):
        """It executes locally a logging command received from the log-server.
        
        Recognized commands are:
            
            - B{LOG_LEV} I{ handlerId, level} sets the severity level of given 
            handler to `level`
            
            - B{LOG_FLT} I{ handlerId, name} sets the filter on loggers' names
            of given handler to `name`
        """
        if cmd == 'LOG_LEV':
            hdlrname, level = rec.split(twnetlog.LogProtocol.LOGSRV_CMD_SEP)
            try:    PythonLoggingObserver_Instanziato.setLevelByN( 
                                                hdlrname, int(level))
            except: pass
        if cmd == 'LOG_FLT':
            hdlrname, name = rec.split(twnetlog.LogProtocol.LOGSRV_CMD_SEP)
            try:    PythonLoggingObserver_Instanziato.setFilterByN( 
                                                hdlrname, name)
            except: pass
    execReceivedCommand = staticmethod(execReceivedCommand)


# allowed handler for the python logging
from logging.handlers import MemoryHandler
__MemBuf = ('MemBuf',(MemoryHandler,(256,)))                # no args
SysOut = ('SysOut',(logging.StreamHandler,(sys.stdout,)))   # no args
SysErr = ('SysErr',(logging.StreamHandler,(sys.stderr,)))   # no args
AppSrv = ('AppSrv',(NetworkClientHandler,()))               # ---
AppFile= ('AppFile',(logging.FileHandler, ()))  # args(filename, mode='a', encoding=None)
AppCircFile = ('AppCircFile',(logging.handlers.RotatingFileHandler, ()))        # args(filename, mode='a', maxBytes=0, backupCount=0, encoding=None
AppDailyFile = ('AppDailyFile',(logging.handlers.TimedRotatingFileHandler, ())) # args(filename, when='h', interval=1, backupCount=0, encoding=None)
__ALLOWED_HANDLERS = ( SysOut, SysErr, AppSrv, 
                     AppFile, AppCircFile, AppDailyFile )

#
FULL_FORMATTER_SEPARATOR =  '|'
FULL_FMT_HEADER = ['date-time', 'logger', 'level', 'module-func' , 'message', 
                   'thread', 'process']
FULL_FORMATTER = logging.Formatter("%(asctime)s" \
                    "|%(name)s|%(levelname)s|%(module)s.%(funcName)s "
                    "(%(lineno)d)| %(message)s|%(thread)d|%(process)d")
"""This formatter will be used with files' handlers. It's a real complete one"""

NETWORK_FORMATTER = FULL_FORMATTER
"""This formatter will be used to send logging message to a B{I{Log Server}}"""

STORAGE_FMT_HEADER = ['reg date-time', 'node', 'process', 'msg date-time', 
                      'logger', 'level', 'module.func(line)' , 'message',
                      'thread', 'process']
STORAGE_FORMATTER = logging.Formatter("%(asctime)s| %(message)s")
"""This formatter will be used from the Log Server to store all collected messages"""

DEFAULT_FORMATTER = logging.Formatter("%(asctime)s.%(msecs)03d " \
            "-%(name)18s-%(levelname)8s- [%(module)s.%(funcName)s] %(message)s",
            datefmt = "%H:%M:%S")
"""This formatter will be used with consolles' handlers. It's a compact one"""

DEFAULT_HANDLER = SysOut
DEFAULT_LEVEL = TRACE   # le successive modifiche di livello non supereranno piu'
                        # il settaggio iniziale (quindi x poterlo modificare a 
                        # piacimento bisogna partire da TRACE)

from twisted.python.log import PythonLoggingObserver
class TwLogging(PythonLoggingObserver):
    """
    TW-logging specific PythonLoggingObserver that will be the only one observer
    of our twisted's log.
    
    It will be instantiated tipically only once, and it will manage all the 
    loggers we create in our application.
    The application doesn't have to instantiate it directly.
    Any way, TwLogging object is not a singleton and, some times, it will be 
    instatiated more than once (see twlogging server).
    
    The application can obtain all its loggers via the usual I{getLogger()} 
    [that will be a twLogging.getLogger() instead of a logging.getLogger()]
    It's allowed to create a TwLogging without any handler.
    By default all the additional loggers will have the same handlers of 
    the first one.
    
    A TwLogging ownes at least one logger. An handler has a severity level and 
    a formatter associated with it self. Handlers are added and deleted at 
    TwLogging's level. All subsequent loggers instantiated via  L{getLogger()} 
    depends from the first one:
        
        - their names append to the root logger name
        
        - their handlers are the same of the root logger handlers
    """
    def __init__(self, loggerName, level = DEFAULT_LEVEL, fmt = None, 
                 bIndependent=False, handlerId = None, *hldrargs, **hldrkwargs):
        """
        @param loggerName:  identifier used to name the logger.
        @type loggerName:   C{str}
        @param level:       logging level at witch will be set the logger
        @type level:        C{str}
        @param fmt:         formatter that will be associated to the 
                            logger's handler
        @type fmt:          C{str}
        @param handlerId:   handler identifier among those that are allowed
                            for a PythonLoggingObserver object 
                            L{__ALLOWED_HANDLERS}
        @type handlerId:    C{tuple} (func,(*args))
        @param hldrargs:    positional arguments required from the handlerId's 
                            instantiation function
        @type hldrargs:     C{list}
        @param hldrkwargs:  keyword arguments required from the handlerId's 
                            instantiation function
        @type hldrkwargs:   C{dictionary}
        """
        PythonLoggingObserver.__init__(self,  loggerName)
        self.logger.observer = self
        if not bIndependent:
            global PythonLoggingObserver_Instanziato
            PythonLoggingObserver_Instanziato = self
        self.loggerName = loggerName
        self.dHdlrFmt = {}
        """self.dHdlrFmt[handlerName] = handlerId
           self.dHdlrFmt[handlerId] = (handler,  fmt,  filter) 
        """
        self.partialPropagation = {}#: self.partialPropagation[logger] = exclude
        if handlerId:
            self.addHdlrWfmt(handlerId, fmt, level, *hldrargs, **hldrkwargs)
        if level:   
            self.logger.setLevel(level)
        log.addObserver(self.emit)

    def addHdlrWfmt(self, handlerId, fmt = None, level = None,
                                    *hldrargs, **hldrkwargs):
        """Adds a new handler to the given TwLogging object. This means that all
        its children loggers will inherit the same handlers (because they 
        normally have a propagate = True policy). Only for loggers created with 
        an `exclude` handlers list will have all the allowed root's handlers  
        directly linked to them.

        An handler has a formatter, a level and a filter associated with it. 
        When its created its filter is empty.
        If the selected handler already belongs to this TwLogging, this method 
        will just modify its formatter and level.
        """
        if handlerId in self.dHdlrFmt.keys():
            handler = self.dHdlrFmt[handlerId][0]
            filter = handler.filters[0]
        else:
            handler = handlerId[1][0](*(handlerId[1][1]+hldrargs),**hldrkwargs)
            filter = logging.Filter('')
            handler.addFilter(filter)
            self.logger.addHandler(handler)
            handler.name = handlerId[0] 
            self.dHdlrFmt[handler.name] = handlerId
        if fmt:     
            handler.setFormatter(fmt)
        if level:   
            self.logger.setLevel(level)
            handler.setLevel(level)
        self.dHdlrFmt[handlerId] = (handler,  fmt,  filter)
        for logger in self.partialPropagation.keys():
            if not handlerId in self.partialPropagation[logger]:
                logger.addHandler(handler)
        return handler

    def removeHandler(self, handlerId):
        """Removes an existing handler from the given TwLogging object. 
        This means that all its children loggers loose that handler implicitly 
        (for propagate = True) or explicitly (for propagate = False).
        """
        if handlerId in self.dHdlrFmt.keys():
            handler = self.dHdlrFmt[handlerId][0]
            handler.close()
            self.logger.removeHandler(handler)
            del self.dHdlrFmt[handlerId], self.dHdlrFmt[handler.name]
            for logger in self.partialPropagation.keys():
                try:
                    logger.removeHandler(handler)
                except:
                    pass

    def __modifyHdlrFmt(self, handlerId, fmt):
        self.dHdlrFmt[handlerId][1] = fmt
        self.dHdlrFmt[handlerId][0].setFormatter(fmt)

    def getLevel(self, handlerId):
        """
        @type handlerId:    C{string} 
        @param handlerId:   handler name

        @rtype:         C{integer} 
        @return:        severity level of given handler
        """
        return self.dHdlrFmt[handlerId][0].level

    def setLevel(self, handlerId, level):
        """Sets the given level on the selected handler. From now on only the 
        messages emitted from that level and all more severe levels will be 
        logged.
        """
        self.dHdlrFmt[handlerId][0].setLevel(level)

    def setFilter(self, handlerId, name):
        """Sets the given filter on the selected handler. From now on only the 
        messages emitted from the corresponding logger and all its depending 
        ones will be logged. [for example name = root.child will show only 
        `root.child` and `root.child.any.thing.else`].
        Only one filter for handler is set.
        """
        self.dHdlrFmt[handlerId][2].__init__( name )

    def setLevelByN(self, handlerName, level):
        """Sets the given level on the selected handler identified by name.
        This commands comes from a different process that doen't know the real
        current handlers configuration so handler can be inactive.
        """
        try:
            handlerId = self.dHdlrFmt[handlerName]
            self.setLevel( handlerId, level)
        except:
            print 'setLevelByN - No handler named ', handlerName

    def setFilterByN(self, handlerName, name):
        """Sets the given filter on the selected handler identified by name.
        This commands comes from a different process that doen't know the real
        current handlers configuration so handler can be inactive.
        """
        try:
            handlerId = self.dHdlrFmt[handlerName]
            self.setFilter( handlerId, name)
        except:
            print 'setFilterByN - No handler named ', handlerName
            
    def __getHdlrFmt(self, handler):
        return self.dHdlrFmt[handler][1]
        
    def copyHandlers(self, logger, exclude):
        """When a new logger has an `exclude` list it will exit from the 
        inheritance policy for propagate=True and it will have all the root 
        handlers (minus the `exclude` ones) directly assigned to it and a
        propagate = False.
        """
        for handlerId in self.dHdlrFmt.keys():
            if not handlerId in exclude and type(handlerId)==types.TupleType:
                handler,  fmt,  filter = self.dHdlrFmt[handlerId]
                logger.addHandler(handler)
                self.partialPropagation[logger]=exclude
        logger.propagate = False
        

def getLogger(loggerName="twLogging", level = DEFAULT_LEVEL, exclude=[], 
                fmt = DEFAULT_FORMATTER, handlerId = DEFAULT_HANDLER,
                *hldrargs, **hldrkwargs):
    """This is the function to return a logger in logging style. 
    
    If a I{PythonLoggingObserver} (L{TwLogging}) is not been intantiated jet, it 
    creates it, because it will be the interface to twisted log system for that 
    and all subsequent loggers.
    The root logger can have an handler and a severity level or not. Any way all
    its descendant loggers will inherit its ones (with the classical logging 
    inheritance policy for propagate=1), unless an exclude list has been passed. 
    In that case, the new logger hinerits all the parent's handlers excluding 
    the ones in the list.
    """
    if PythonLoggingObserver_Instanziato:
        logger = logging.getLogger(
                    PythonLoggingObserver_Instanziato.loggerName+'.'+loggerName)
        logger.observer = PythonLoggingObserver_Instanziato
        if level: 
            logger.setLevel(level)
        if exclude: 
            PythonLoggingObserver_Instanziato.copyHandlers(logger,  exclude)
        return logger
    else:
        observer = TwLogging(loggerName, level=level, fmt=fmt, 
                             handlerId=handlerId, *hldrargs, **hldrkwargs)
        return observer.logger


def getLoggerNames():
    return logging.Logger.manager.loggerDict.keys()


def addHandler2Loggers(handlerId, level=DEFAULT_LEVEL, fmt=DEFAULT_FORMATTER, 
                                    *hldrargs,**hldrkwargs):
    """If you use logging style getLogger() you'll use this to add handlers to
    I{PythonLoggingObserver}. 
    """
    if PythonLoggingObserver_Instanziato:
        PythonLoggingObserver_Instanziato.addHdlrWfmt(handlerId, fmt, level,
                                                        *hldrargs, **hldrkwargs)
    else:
        raise 'No loggers'

def removeHandlerFromLoggers(handlerId):
    """If you use logging style getLogger() you'll use this to remove handlers 
    from I{PythonLoggingObserver}. 
    """
    if PythonLoggingObserver_Instanziato:
        PythonLoggingObserver_Instanziato.removeHandler(handlerId)
    else:
        raise 'No loggers'


    