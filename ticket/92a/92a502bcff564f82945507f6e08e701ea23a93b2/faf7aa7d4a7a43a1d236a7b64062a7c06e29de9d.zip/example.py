
import twlogging
loggerR = twlogging.getLogger('TEST')
loggerL = twlogging.getLogger('CHILD')

from twisted.python import log

def logLogger():
    loggerR.info('this is the root logger')
    loggerL.info('this is the child logger')

    loggerR.critical('this is the root logger')
    loggerL.critical('this is the child logger')

    log.msg('twisted log message')
    log.err('twisted error message')

print 'stdout only'
logLogger()
twlogging.addHandler2Loggers(twlogging.SysErr)
print 'stdout & stderr'
logLogger()
twlogging.PythonLoggingObserver_Instanziato.setFilter(twlogging.SysOut,'TEST.CHILD')
print 'filter on CHILD on out'
logLogger()
twlogging.PythonLoggingObserver_Instanziato.setFilter(twlogging.SysOut,'TEST')
print 'filter on TEST on out'
logLogger()
twlogging.PythonLoggingObserver_Instanziato.setLevel(twlogging.SysErr,twlogging.ERROR)
print 'level ERROR on err'
logLogger()

