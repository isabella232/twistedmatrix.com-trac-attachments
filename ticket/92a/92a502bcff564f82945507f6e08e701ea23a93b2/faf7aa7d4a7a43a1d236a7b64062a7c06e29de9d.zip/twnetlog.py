#!/usr/bin/env python
# -*- coding: utf-8 -*-#
# -*- test-case-name: test_twnetlog.py -*-
#-------------------------------------------------------------------------------
# Name:        twnetlog.py
# Purpose:     Client-server twisted connection to dispatch log messages.
#
# Author:      Licia Leanza
# E-mail:      guarda.sw@gmail.com
#
# Created:     20-02-2008
# RCS-ID:      $Id: twnetlog.py 3 2008-05-22 15:34:14Z licia $
# Copyright:   (c) Licia Leanza: 2006-2008
# Licence:     LGPL 
# Package:     twlogging
#-----------------------------------------------------------------------------
"""
Protocol and Factory to send logging messages via a twisted connection to a 
B{log-serverv}.
It offers a network connection to a L{twlogging.NetworkClientHandler} via 
Twisted.

G{classtree LogProtocol,_LogClientFactory,_LogClientProtocol,_LogServerFactory,
_LogServerProtocol}
@newfield slot: Slot, Slots
"""
import logging.config
__version__ = "$Rev: 3 $"
__docformat__ = "epytext en"

import time, string,  os.path,  sys,  types
from defines import LOG_SRV_DATA_LOGGER, LOCAL_HOST, TWLOGGING_PORT
import defines


from twisted.internet.protocol import  ReconnectingClientFactory,  ServerFactory
from twisted.protocols import basic


class LogProtocol(basic.LineOnlyReceiver):
    """LogProtocol parser.
    
    It recognizes LogProtocol commands. They are specific with respect to the 
    transmission versus.

    Recognized commands from server to client are:
        
        - B{LOG_LEV} I{ handlerId, level} sets the severity level of given 
          handler to `level`
        
        - B{LOG_FLT} I{ handlerId, name} sets the filter on loggers' names
          of given handler to `name`

    Recognized commands from client to server are:
        
        - B{LOG_CLI} I{ node, name, pid} notify to the server the identity of 
          the just connected client
        
        - B{LOG_MSG} I{ process, logmessage } sends a logmessage from given 
          process to server that will storage it.
        
        - B{RED_LEV} I{ handlerId, level, cliName} asks to redirect given 
          `set level` command to `cliName` client
        
        - B{RED_FLT} I{ handlerId, filter, cliName} asks to redirect given 
          `set filter` command to `cliName` client
        
    Recognized requests from client to server are:
        
        - B{ASK_CLN} asks log-server for its connecte clients list

    Answers to requests from client to server are:
        
        - B{ANS_CLN} I{ list[cliNames]} is the answer to a `ASK_CLN` answer; it 
        has a variable length number of record fields
        
    LogProtocol `rec` is a multi-field string with fields delimited by
    L{LogProtocol.LOGSRV_CMD_SEP}

    basic.LineOnlyReceiver is an ASCII protocol. It transports lines terminated 
    from a L{LogProtocol.delimiter}
    """
    cmds = {    'LOG_MSG': 8,
                'LOG_CLI': 3,
                'LOG_LEV': 2,
                'LOG_FLT': 2,
                'ASK_CLN': 0,   # no rec
                'ANS_CLN': -1,  # rec-fields number not constant
                'RED_LEV': 3,
                'RED_FLT': 3,
            }
    errors = {  'UNKNOWN_COMMAND':      'UNKNOWN_COMMAND',
                'BAD_RECORD_FORMAT':    'BAD_RECORD_FORMAT',
            }
    LOGSRV_CMD_SEP = '|'
    delimiter = '@'+basic.LineOnlyReceiver.delimiter+'@'
    def closeConnection(self):
        self.transport.loseConnection()
    def sendLine(self, line):
        self.transport.write( "%s%s" % (line,  self.delimiter)) 
    def parse(self, line):
        """
        Parses given line.

        @type line: C{string}
        @param line: ASCII line transmitted over connection. It must be a valid 
                    command of the form: |cmd|rec| where `cmd` must belong to
                    L{LogProtocol.cmds}.keys() and `rec` must be of 
                    L{LogProtocol.cmds}[cmd] number of fields separated by `|`.

        @rtype: C{tuple} 
        @return: (cmd, rec) command and record of given line. If parsing was not 
                OK and error is returned into cmd. It could be one among 
                L{LogProtocol.errors}.keys()
        """
        try:
            cmd, rec = line.split(LogProtocol.LOGSRV_CMD_SEP, 1)
            if not cmd in self.cmds.keys():
                cmd = self.errors['UNKNOWN_COMMAND']
            else:
                if self.cmds[cmd]!= -1 and len(
                    rec.split(LogProtocol.LOGSRV_CMD_SEP)) != self.cmds[cmd]:
                    cmd = self.errors['BAD_RECORD_FORMAT']
        except:
            cmd = line
            if not cmd in self.cmds.keys():
                cmd = self.errors['UNKNOWN_COMMAND']
            elif not self.cmds[cmd] :
                rec = ''
            else:
               cmd = self.errors['BAD_RECORD_FORMAT']
               rec = line
        return cmd, rec
    def _normalize2ascii(self, line):
        if type(line) == types.UnicodeType :
            line = line.encode('utf_8','replace')
        return line
        

class _LogClientProtocol(LogProtocol):
    """Client side LogProtocol manager.

    @slot: connectionMade() called when the connection is established
    @slot: connectionLost() called when the connection is lost
    @slot: lineReceived()   called when a line is received
    """
    def __init__(self):
        logger.trace('')
    def connectionMade(self):
        logger.trace('')
        self.notifyIdentity()
    def connectionLost(self, reason='protocol requested'):
        logger.error('Lost connection: %s '%reason)
    def lineReceived(self, line):
        logger.trace('ricevuto %s', line)
        cmd,  rec = self.parse(line)
        if not cmd in LogProtocol.errors.keys():
            self.factory.OnCommandReceived(cmd, rec)
        else:
            logger.error('Bad message received <%s>: %s (%d chars)'%(cmd,rec,len(rec)))
    def notifyIdentity(self):
        """Sends a B{LOG_CLI} message with client identity to log-server"""
        self.sendLine(LogProtocol.LOGSRV_CMD_SEP.join(['LOG_CLI',
                    self.factory.node, self.factory.process,self.factory.pid])) 
    def sendLogMsg(self, line):
        """Sends a B{LOG_MSG} message with a log message to log-server"""
        self.sendLine(LogProtocol.LOGSRV_CMD_SEP.join(['LOG_MSG',
                    self.factory.process, self._normalize2ascii(line)]))
    def askClientsNames(self):
        """Sends a B{ASK_CLN} request message to log-server"""
        self.sendLine(LogProtocol.LOGSRV_CMD_SEP.join(['ASK_CLN']))
    def sendLevel(self, hdlrname, lev, cliName ):
        """Sends a B{RED_LEV} message with a setLevel command to redirect to
        cliName client toward log-server"""
        self.sendLine(LogProtocol.LOGSRV_CMD_SEP.join(['RED_LEV', 
                            hdlrname, str(lev),cliName ]))
    def sendFilter(self, hdlrname, filter, cliName ):
        """Sends a B{RED_FTL} message with a setFilter command to redirect to
        cliName client toward log-server"""
        self.sendLine(LogProtocol.LOGSRV_CMD_SEP.join(['RED_FLT', 
                            hdlrname,self._normalize2ascii(filter),cliName ]))


class _LogClientFactory(ReconnectingClientFactory):
    """
    @slot:     startedConnecting() 
    @slot:     buildProtocol()
    @slot:     clientConnectionLost()
    @slot:     clientConnectionFailed()
    @slot:     OnCommandReceived() a log-server command has been received

    """ 
    proto = None
    protocol = _LogClientProtocol 
    def __init__(self,  oncmd):
        """
        @param oncmd: a function that is able to accept (cmd, rec) arguments; it
                      will be called when a log-server command is received.
        @type oncmd: C{callable}
        """
        import platform
        self.node = '//%s//'%platform.node()
        if hasattr(os, 'getpid'):
            self.pid = str(os.getpid())
        else:
            self.pid = '-'
        self.process,  ext = os.path.splitext(os.path.basename(sys.argv[0]))
        self.process = str(self.process)
        self._loggedConnectionError = False
        if callable(oncmd):  
            self.OnCommandReceived = oncmd
    def startedConnecting(self, connector): 
        logger.trace('')
        self.resetDelay()
    def buildProtocol(self, addr): 
        logger.trace('')
        self.proto = self.protocol()
        self.proto.factory = self
        self._loggedConnectionError = False 
        return self.proto
    def clientConnectionLost(self, connector, reason): 
        logger.trace('')
        self.proto = None 
        ReconnectingClientFactory.clientConnectionLost(self, connector, reason) 
    def clientConnectionFailed(self, connector, reason):
        sreason = '%s' % reason
        if self._loggedConnectionError != sreason:
            logger.error(sreason )
            self._loggedConnectionError = sreason
        self.proto = None
        ReconnectingClientFactory.clientConnectionFailed(self,connector,reason)
    def sendLogMsg(self, line):
        """Sends a log message to log-server"""
        if self.proto:      self.proto.sendLogMsg( line ) 
        else:  logger.debug( 'Cant write to socket: connection down. <%s>'%line)
    def stop(self):
        """Shutsdown log-server connection"""
        logger.info('_LogClientFactory received a stop command: '\
                    'performing shutdown ...') 
        self.continueTrying = False
        self.stopTrying()
        if self.proto:   self.proto.closeConnection()
    def OnCommandReceived(self, cmd, rec):
        """This method must be overridden by oncmd parameter on factory creation
        """
        logger.debug( 'Command <%s> received with no callable defined. [%s]'
                         %(cmd, rec))

        raise 'Not implemented - this must be overridden'
    def askClientsNames(self):
        """Sends a request message of connected clients names to log-server"""
        if self.proto:      self.proto.askClientsNames()
    def sendLevel(self, hdlrname, lev, cliName ):
        """Sends a sendLevel command to be redirected to cliName client toward 
        log-server
        """
        if self.proto:      self.proto.sendLevel( hdlrname, lev, cliName )
    def sendFilter(self, hdlrname, filter, cliName ):
        """Sends a setFilter command to be redirected to cliName client toward 
        log-server
        """
        if self.proto:      self.proto.sendFilter( hdlrname, filter, cliName )

class _LogServerProtocol(LogProtocol):
    """Server side of a LogProtocol commection. One instance for each connected 
    client.

    @slot: connectionMade() called when the connection is established
    @slot: connectionLost() called when the connection is lost
    @slot: lineReceived()   called when a line is received
    """
    def __init__(self):
        logTrace('')
    def connectionMade(self):
        logTrace('')
        self.factory.addClient(self)
    def connectionLost(self, why):
        logTrace('')
        self.factory.removeClient(self)
    def lineReceived(self, line):
        logTrace('ricevuto %s', line)
        cmd,  rec = self.parse(line)
        if cmd == 'LOG_CLI':
         self.factory.storeClientId(self,*rec.split(LogProtocol.LOGSRV_CMD_SEP))
        elif cmd == 'LOG_MSG':
            self.factory.storeMessage(self,  rec)
        elif cmd == 'ASK_CLN':
            self.sendLine(LogProtocol.LOGSRV_CMD_SEP.join(
                                    ['ANS_CLN']+self.factory.getClientsNames()))
        elif cmd == 'RED_LEV':
            hdlrName, lev, cliName  = rec.split(LogProtocol.LOGSRV_CMD_SEP)
            self.factory.sendLevel( hdlrName, lev, cliName, 'redirLevel')
        elif cmd == 'RED_FLT':
            hdlrName, filter, cliName  = rec.split(LogProtocol.LOGSRV_CMD_SEP)
            self.factory.sendFilter( hdlrName, filter, cliName, 'redirFilter')
        else:
            logError('Bad message received <%s>: %s (%d chars)' %
                                                            (cmd,rec,len(rec)))
    def sendLevel(self, hdlrname, lev ):
        """Sends a B{LOG_LEV} command to its client"""
        self.sendLine(LogProtocol.LOGSRV_CMD_SEP.join(['LOG_LEV',
                hdlrname, str(lev)]))
    def sendFilter(self, hdlrname, filter ):
        """Sends a B{LOG_FLT} command to its client"""
        self.sendLine(LogProtocol.LOGSRV_CMD_SEP.join(['LOG_FLT',
                                      hdlrname,self._normalize2ascii(filter)]))
    def redirLevel(self, hdlrName, lev ):
        """Redirects a B{LOG_FLT} command to its client"""
        self.sendLine(LogProtocol.LOGSRV_CMD_SEP.join(
                                              ['LOG_LEV', hdlrName, str(lev)]))
    def redirFilter(self, hdlrName, filter ):
        """Redirects a B{LOG_FLT} command to its client"""
        self.sendLine(LogProtocol.LOGSRV_CMD_SEP.join(
                         ['LOG_FLT', hdlrName, self._normalize2ascii(filter)]))


class _LogServerFactory(ServerFactory): 
    """Server side manager of all clients connections.
    
    Main task of a log-server is to do a centralized storaging of all I{log 
    messages}. 
    
    To do this it will use storageLogger based on a circular file facility or
    a daily one. You can change this editing L{defines} module.
    
    @slot:     buildProtocol()
    @slot:     addClient() called when a client connection has been made
    @slot:     removeClient() called when a client connection has been lost
    @slot:     storeClientId() manages a `LOG_CLI` command
    @slot:     storeMessage() manages a `LOG_MSG` command
    """ 
    protocol = _LogServerProtocol
    def __init__(self, storeLogger=LOG_SRV_DATA_LOGGER):
        self.loggerStore = storeLogger()
        logTrace('')
        self._clients = []
        self._clientsId = {}
    def buildProtocol(self, addr): 
        logTrace('')
        proto = self.protocol()
        proto.factory = self
        return proto
    def addClient(self,  cli):
        self._clients.append(cli)
    def removeClient(self,  cli):
        self._clients.remove(cli)
        try:
            del self._clientsId [cli.clientId]
        except:     pass
    def storeClientId(self, cli, node, name, pid):
        """Handles `LOG_CLI` message"""
        cli.clientId ='%s.%s (%s)'%(node, name, pid)
        self._clientsId [cli.clientId] = cli
        cli.node = node
    def storeMessage(self, cli, rec):
        """Handles `LOG_MSG` message"""
        self.loggerStore.trace(LogProtocol.LOGSRV_CMD_SEP.join([cli.node,rec]))
    def stop(self):
        """Shutsdown all its connections"""
        logTrace('LogServerFactory received a stop command: '\
                    'performing shutdown ...') 
        for cli in self._clients:
            cli.closeConnection()
        self.porta.stopListening()
    def getClientsNames(self):
        """
        @rtype: C{list[string]} 
        @return: list of string identifiers ('node name pid') of eache connected 
                 client to this server
        """
        return self._clientsId.keys()
    def sendLevel(self, hdlrname, lev, cliName, sendFunc='sendLevel' ):
        """Sends or redirect a setLevel command to cliName client depending on
        sendFunc value
        """
        self.__sendCmd( cliName, sendFunc,  hdlrname, lev )
    def sendFilter(self, hdlrname, filter, cliName, sendFunc='sendFilter' ):
        """Sends or redirect a setFilter command to cliName client depending on
        sendFunc value
        """
        self.__sendCmd( cliName, sendFunc,  hdlrname, filter )
    def __sendCmd(self, cliName, funName,   *args ):
        try:
            cli = self._clientsId[cliName]
        except:
            logTrace('Client %s no more connected' % cliName)
            return
        getattr(cli, funName)(*args)

try:
    logger,  logTrace, logError
except:
    logger = None
    logTrace = None
    logError = None
    
def startLogClient( host = LOCAL_HOST, port = TWLOGGING_PORT, oncmd = None): 
    """Instantiate a LogClient for a log-server connection towards `host:port` 
    If the clients handles log-server commands a `oncmd` callable must be given
    """
    global logger
    if not logger:
        import twlogging
        logger = twlogging.getLogger('LOGC',  exclude =[twlogging.AppSrv])
    from twisted.internet import reactor
    factory = _LogClientFactory(oncmd)
    reactor.connectTCP(host, port, factory)
    return factory

def startLogSever(port=TWLOGGING_PORT,storeLogger=LOG_SRV_DATA_LOGGER,log=None): 
    """Instantiate a LogServer object that will listen on `port` for log-clients
    connections and will storage all log messages received from its clients on 
    `filename` file.
    Process logs will inherit current twlogging handlers.
    """
    from twisted.internet import reactor
    factory = getLogSeverFactory(storeLogger,log)
    factory.porta = reactor.listenTCP(port, factory)
    return factory

def getLogSeverFactory(storeLogger=LOG_SRV_DATA_LOGGER, log=None): 
    """It creates a L{_LogServerFactory}. That object will log to a twlogging's
    logger if the server is instatiated via startLogServer, will log to
    twisted log if it is run like an application.
    """
    global logTrace, logError
    if not log:
        import twlogging
        logger = twlogging.getLogger('LOGS', exclude = [twlogging.AppSrv])
        logTrace = logger.trace
        logError = logger.error
    else:
##        logTrace = log.msg
        logTrace = noLogTrace
        logError = log.err
    factory = _LogServerFactory(storeLogger)
    return factory

def noLogTrace(*a):
    pass

if __name__ == '__main__':
    """It starts a log-server like a console process that logs to console"""
    factory = startLogSever()
    from twisted.internet import reactor
    reactor.run()


