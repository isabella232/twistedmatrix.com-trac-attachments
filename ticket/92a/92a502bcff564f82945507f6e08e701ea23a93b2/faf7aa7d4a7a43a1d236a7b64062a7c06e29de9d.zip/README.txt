----------
22/05/2008
----------

This is a module's subset from my TWLogging package [http://sourceforge.net/projects/twlogging/] that could be useful as an extention to twisted PythonLoggingObserver.
It implements:
  1- a NetworkHandler class [twlogging.NetworkClientHandler] using a Twisted TCP connection
  2- a log-server [twlserver.tac] that receives all incoming log messages from network's clients and stores them onto a central logging file 
  3- a simple protocol that allowes dinamyc variations of logging configuration
  4- a unittest module [test_twl.py] that tests it main features.

In my TWLogging package there is also a GUI to browse twlogging files and to send re-configuration commands interactively. I didn't include it here because it depends on QT4, so I think it is not pertinent in this place.
I'm planning  to implement logging.config using twisted sockets.