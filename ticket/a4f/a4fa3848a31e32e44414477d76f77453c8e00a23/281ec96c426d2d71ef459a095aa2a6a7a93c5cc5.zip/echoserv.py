#!/usr/bin/python
from twisted.internet import reactor, protocol, task, defer
from twisted.protocols.basic import LineOnlyReceiver
import time

class ClientProtocol(LineOnlyReceiver):

    # On connect, send an increasingly large amount of data
    def connectionMade(self):
        self.factory.clientConnectionMade(self)
        
        # Send a bunch of data!
        sampledata = "X"
        
        for x in range(15):
            try:
                print "Message length: " + str(len(sampledata)) + " characters"
                line = sampledata + " \r\n"
                self.transport.write(line)
                sampledata = sampledata + sampledata
            except:
                print "Ran out of memory!"
                return
    
    def connectionLost(self, reason):
        self.factory.clientConnectionLost(self)

class ClientFactory(protocol.Factory):
    protocol = ClientProtocol
                
    def clientConnectionMade(self, client):
        print "Client connected"

    def clientConnectionLost(self, client):
        print "Client Disconnected"

ClientFactory = ClientFactory()
reactor.listenTCP(24020, ClientFactory)
reactor.run()