from twisted.internet import iocpreactor
iocpreactor.install()

from twisted.internet import reactor, task, interfaces
from twisted.internet.protocol import ClientFactory, Factory, Protocol
from DownloadRateLimiter import DownloadRateLimiter, ThrottleListener

drl = DownloadRateLimiter(1.0, 50 * 1024)

class ThrottleProtocol(ThrottleListener, Protocol):

    def connectionMade(self):
        self.paused = False
        drl.add_throttle_listener(self)
        print "connection made", self.transport.getPeer()

    def dataReceived(self, data):
        #print "dataReceived", len(data)
        drl.update_rate(len(data))
        
    def connectionLost(self, reason):
        drl.remove_throttle_listener(self)
        print 'connection lost', reason.getErrorMessage()

    def throttle_connections(self):
        self.pause_reading()
        
    def unthrottle_connections(self):
        self.resume_reading()

    def pause_reading(self):
        # interfaces are the stupedist crap ever
        if (hasattr(interfaces.IProducer, "providedBy") and
            not interfaces.IProducer.providedBy(self.transport)):
            print "No producer", self.ip, self.port, self.transport
            return
        # not explicitly needed, but iocpreactor has a bug
        if self.paused:
            return
        self.transport.pauseProducing()
        self.paused = True

    def resume_reading(self):
        if (hasattr(interfaces.IProducer, "providedBy") and
            not interfaces.IProducer.providedBy(self.transport)):
            print "No producer", self.ip, self.port, self.transport
            return
        # not explicitly needed, but iocpreactor has a bug
        if not self.paused:
            return
        self.paused = False
        try:
            self.transport.resumeProducing()
        except Exception, e:
            # I bet these are harmless
            print "resumeProducing error", type(e), e

class SpewProtocol(Protocol):

    def connectionMade(self):
        self.task = task.LoopingCall(self.write)
        self.task.start(0.01)

    def write(self):
        self.transport.write('*' * 2048)

    def connectionLost(self, reason):
        self.task.stop()
        
port = 8000

f = Factory()
f.protocol = SpewProtocol
reactor.listenTCP(port, f)

for i in xrange(5):
    f = ClientFactory()
    f.protocol = ThrottleProtocol
    reactor.connectTCP('localhost', port, f)

reactor.run()