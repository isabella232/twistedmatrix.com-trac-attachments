zone = [
    SOA('testing123.com',
        mname = 'ns1.testing123.com',
        rname = 'root.testing123.com',
        serial = 2003010601,
        refresh = '0',
        retry = '0',
        expire = '0',
        minimum = '0'
    ),
    NS('testing123.com','ns1.testing123.com', 3600),
    A('testing123.com', '127.0.0.1', 0),
    A('mail.testing123.com', '127.0.0.1', 3600),
    MX('mail.testing123.com', 0, 'testing123.com', 3600),
    CNAME('ftp.testing123.com','testing123.com', 3600),
    CNAME('www.testing123.com','testing123.com', 0),
    CNAME('testcname.testing123.com','www.google.com', 0),
    A('test.testing123.com', '127.0.0.1', 0)
]
