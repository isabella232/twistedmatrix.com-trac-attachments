from twisted.application import service, internet
from twisted.internet import reactor, defer
from twisted.python import components, log
from twisted.names import server, dns, client, resolve, common, authority
from zope.interface import Interface, implements

class IDNSServerFactory(Interface):
    pass

class IDNSService(Interface):
    pass

class TESTDNSServerFactoryFromService(server.DNSServerFactory):
    implements(IDNSServerFactory)
    def __init__(self, service):
        self.service = service
        self.caches = None
        self.clients = None
        if (service.mAltDnsServer != ''):
            self.clients = [client.Resolver(servers=[
                (self.service.mAltDnsServer, self.service.mAltDnsPort)])
            ]
        self.verbose = 1
        self.resolvers = self.service.mZones
        server.DNSServerFactory.__init__(self, self.resolvers,
                                         self.caches, self.clients,
                                         self.verbose)

        # And finally, let's tell our service where we are...
        self.service.mDnsFactory = self

components.registerAdapter(TESTDNSServerFactoryFromService,
                           IDNSService,
                           IDNSServerFactory)

class TESTResolverService(service.Service):
    implements(IDNSService)
    def __init__(self, config):
        self.mAltDnsServer = config['alt_server']
        self.mAltDnsPort = config['alt_port']
        self.mAuthority = config['authority_file']
        self.mDnsFactory = None # this will be set by the factory on init
        self.mZones = []
        self.readPySource()

    def readPySource(self):
        self.mZones.append(authority.PySourceAuthority(self.mAuthority))
        return


application = service.Application('testing_dns')
serviceCollection = service.IServiceCollection(application) 

config = {'alt_server':'8.8.8.8',
          'alt_port':53,
          'authority_file':'testing123.com.py'}

dns_resolver_service = TESTResolverService(config)
dns_resolver_service.setName('dns')
dns_resolver_service.setServiceParent(serviceCollection)
# End Resolver Service

# TCP DNS
tcp_dns_factory = TESTDNSServerFactoryFromService(dns_resolver_service)
dns_tcp_inet_service = internet.TCPServer(53, tcp_dns_factory)
dns_tcp_inet_service.setName('dnsTcpInetService')
dns_tcp_inet_service.setServiceParent(serviceCollection)
# End TCP DNS

# UDP DNS
tcp_udp_factory = dns.DNSDatagramProtocol(tcp_dns_factory)
dns_udp_inet_service = internet.UDPServer(53, tcp_udp_factory)
dns_udp_inet_service.setName('dnsUdpInetService')
dns_udp_inet_service.setServiceParent(serviceCollection)
# End UDP DNS

    
    
