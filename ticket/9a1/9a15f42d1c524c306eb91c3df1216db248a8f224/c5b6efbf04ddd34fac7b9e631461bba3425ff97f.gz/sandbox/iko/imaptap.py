import imap4proxy 

from twisted.internet import ssl
from twisted.python import usage        # twisted command-line processing

class Options(usage.Options):
    optParameters = [["port", "p", 143,
                      "Port number to listen on for IMAP connections."],
                     ["rport", "P", 143,
                      "Remote port to connect to."],
                     ["rhost", "h", None,
                      "Remote host to connect to."]]

def updateApplication(app, config):
    port = int(config["port"])          # TCP port to listen on
    factory = imap4proxy.IMAP4ProxyFactory(config["rhost"],
                                           config["rport"])
    # Finally, set up our factory, with its custom quoter, to create QOTD
    # protocol instances when events arrive on the specified port.
    app.listenTCP(port, factory)
