# Twisted, the Framework of Your Internet
# Copyright (C) 2001 Matthew W. Lefkowitz
#
# This library is free software; you can redistribute it and/or
# modify it under the terms of version 2.1 of the GNU Lesser General Public
# License as published by the Free Software Foundation.
#
# This library is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public
# License along with this library; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

"""
An IMAP4 proxy using the IMAP4 client and server

This is mainly a demonstrator for the IMAP4 code so far. It only
supports proxying one server currently.

API Stability: unstable

@author: U{Anders Hammarquist<mailto:iko@cd.chalmers.se>}
"""

from twisted.protocols import imap4
from twisted.internet import protocol, reactor, ssl, defer
from twisted.cred import perspective
from twisted.python import log

from email.Parser import Parser

class IMAP4ProxyFactory(protocol.ServerFactory):
    def __init__(self, rhost=None, rport=143, ctxF=None):
        self.rhost = rhost
        self.rport = rport
        self.ctxF = ctxF
        self.protocol = IMAP4Proxy

    def buildProtocol(self, addr):
        p = self.protocol(self.rhost, self.rport, self.ctxF)
        p.factory = self
        return p

class IMAP4Proxy(imap4.IMAP4Server):
    def __init__(self, host=None, port=143, ctxF=None):
        imap4.IMAP4Server.__init__(self, contextFactory=ctxF)
        self.accountFactory = ProxyAccountFactory(host, port, ctxF)

    def authenticateLogin(self, user, passwd):
        res =  self.accountFactory.getAccount(user, passwd)
        log.debug('authenticateLogin',repr(res))
        res.addCallbacks(self._print, self._print)
        return res

    def _print(self, data):
        log.debug('_print', data)
        return data
    

class ProxyAccountFactory(protocol.ClientCreator):
    def __init__(self, host, port, ctxF=None):
        if ctxF is None:
            ctxF = ssl.ClientContextFactory()
            ctxF.method = ssl.SSL.TLSv1_METHOD
        protocol.ClientCreator.__init__(self, reactor, ProxyIMAPClient,
                                        ctxF)
        self.host = host
        self.port = port

    def getAccount(self, user, passwd):
        dfr = self.connectTCP(self.host, self.port)
        log.debug('getAccount connecting to', self.host, self.port)
        dfr.addCallback(self._doLogin, user, passwd)
        dfr.addErrback(log.err)
        return dfr

    def _doLogin(self, client, user, passwd):
        log.debug('connected, sending login')
        dfr = client.login(user, passwd)
        dfr.addCallback(self._loginOk, client, user)
        return dfr

    def _loginOk(self, result, client, user):
        log.debug('login ok')
        acct = ProxyAccount(user, client)
        return (imap4.IAccount, acct, client.logout)

class ProxyIMAPClient(imap4.IMAP4Client):
    def __init__(self, ctxF = None):
        imap4.IMAP4Client.__init__(self, ctxF)

        self.selectedMbox = None

    def modeChanged(self, writable):
        if self.selectedMbox:
            self.selectedMbox.modeChanged(writable)

    def flagsChanged(self, newFlags):
        if self.selectedMbox:
            self.selectedMbox.flagsChanged(newFlags)

    def newMessages(self, exists, recent):
        if self.selectedMbox:
            self.selectedMbox.newMessages(exists, recent)
    
class ProxyAccount(perspective.Perspective):
    __implements__ = (perspective.Perspective.__implements__, imap4.IAccount,)
    
    def __init__(self, user, client):
        perspective.Perspective.__init__(self, user, user)
        self.client = client

    def addMailbox(self, name, mbox = None):
        return 0 # Can't add mailboxes, only create

    def create(self, pathspec):
        return self.client.create(pathspec)

    def select(self, name, rw=1):
        if rw:
            dfr = self.client.select(name)
        else:
            dfr = self.client.examine(name)

        dfr.addCallback(self._cbSelect, name, rw)
        return dfr

    def _cbSelect(self, datum, name, rw):
        mbox = ProxyMailbox(self.client, datum, name, rw)
        self.client.selectedMbox = mbox
        return mbox.fetchInitial()

    def delete(self, name):
        return self.client.delete(name)

    def rename(self, oldname, newname):
        return self.client.rename(oldname, newname)

    def isSubscribed(self, name):
        dfr = self.client.lsub('',name)
        dfr.addCallback(self._cbIsSubscribed, name)
        return dfr

    def _cbIsSubscribed(self, mboxes, name):
        for flags, hier, mbox in mboxes:
            if mbox == name:
                return 1

        return 0

    def subscribe(self, name):
        return self.client.subscribe(name)

    def unsubscribe(self, name):
        return self.client.unsubscribe(name)

    def listMailboxes(self, ref, wildcard):
        dfr = self.client.list(ref, wildcard)
        dfr.addCallback(self._cbListMailboxes)
        
        return dfr

    def _cbListMailboxes(self, data):
        res = []
        for flags, delim, name in data:
            res.append((name, ProxyMailbox(self.client,
                                           { 'FLAGS' : flags },
                                           name, 0, delim)))
        return res

class ProxyMailbox(object):
    __implements__ = (imap4.IMailbox, imap4.IMailboxListener)

    def __init__(self, client, datum, name, rw, delim = None):
        self.name = name
        self.client = client
        self.status = datum
        self.status.setdefault('READ-WRITE', rw)
        self.uids = []
        self.delimiter = delim
        self.listeners = []

    def modeChanged(self, writable):
        self.status['READ-WRITE'] = writable
        for l in listeners:
            l.modeChanged(writable)

    def flagsChanged(self, newFlags):
        # Cache?
        for l in listeners:
            l.flagsChanged(newFlags)

    def newMessages(self, exists, recent):
        if exists is not None:
            # We need to repopulate the cache...
            dfr = self.client.fetchUID(imap4.MessageSet(len(self.uids),
                                                        exists))
            dfr.addCallback(self._cbNewMessages, exists, recent)
        else:
            self.status['RECENT'] = recent
            for l in listeners:
                l.newMessages(exists, recent)

    def _cbNewMessages(self, mUids, exists, recent):
        mUids = mUids.items()
        mUids.sort()
        self.uids[mUids[0][0]-1:exists] = [m[1] for m in mUids]

        self.status['RECENT'] = recent
        self.status['EXISTS'] = exists
        for l in listeners:
            l.newMessages(exists, recent)

    def fetchInitial(self):
        """Fetch status needed for cache.

        MUST be called before getUID is invoked.
        """
        if self.status['EXISTS'] > 0:
            dfr = self.client.fetchUID(imap4.MessageSet(1,None))
        else:
            dfr = defer.succeed({})

        dfr.addCallback(self._cbFetchInitial)
        
        return dfr

    def _cbFetchInitial(self, mUids):
        mUids = mUids.items()
        mUids.sort()
        self.uids = [m[1] for m in mUids]
        if self.delimiter is None:
            dfr = self.client.list(self.name, "")
            dfr.addCallback(self._cbDelimiter)
            return dfr
        else:
            return self

    def _cbDelimiter(self, data):
        self.delimiter = data[0][1]
        return self

    def getUIDValidity(self):
        return self.status.setdefault('UIDVALIDITY', 0)

    def getUIDNext(self):
        return self.status.setdefault('UIDNEXT', 0)

    def getUID(self, mId):
        return self.uids[mId-1]

    def getFlags(self):
        return self.status.setdefault('FLAGS', [])

    def getMessageCount(self):
        return self.status.setdefault('EXISTS', 0)

    def getRecentCount(self):
        return self.status.setdefault('RECENT', 0)

    def getUnseenCount(self):
        return self.status.setdefault('UNSEEN', 0)

    def isWriteable(self):
        return self.status['READ-WRITE']

    def destroy(self):
        self.status['FLAGS'].append(r'\Noselect')
        self.client.selectedMbox = None
        return self.client.delete(self.name)

    def getHierarchicalDelimiter(self):
        return self.delimiter

    def requestStatus(self, names):
        dfr = self.client.status(self.name, *names)
        dfr.addCallback(self._cbRequestStatus)
        return dfr

    def _cbRequestStatus(self, status):
        # Make sure cached status is in sync
        self.status.update(status)
        return status
        

    def addListener(self, listener):
        self.listeners.append(listener)

    def removeListener(self, listener):
        self.listeners.remove(listener)
    
    def addMessage(self, message, flags = (), date = None):
        dfr = self.client.append(self.name, message, flags, date)
        dfr.addCallback(self._cbAddMessage)
        return dfr

    def _cbAddMessage(self, spam):
        return 0 # XXX

    def expunge(self):
        return self.client.expunge()

    def search(self, query, uid=0):
        return self.client.search(imap4.collapseNestedLists(query), uid=uid)

    def fetch(self, messages, uid=0):
        res = []

        if uid:
            messages.last = self.uids[-1]
            for msg in range(len(self.uids)):
                uid = self.uids[msg-1]
                if uid in messages:
                    res.append((msg,ProxyMessage(msg, uid, self.client)))
        else:
            messages.last = len(self.uids) - 1
            for msg in messages:
                res.append((msg,
                            ProxyMessage(msg, self.uids[msg-1], self.client)))

        return iter(res)

    def store(self, messages, flags, mode, uid):
        dfr = self.client._store(str(messages), '%sFLAGS' %
                                 ['-', '' , '+'][mode+1],
                                 flags, uid)
        dfr.addCallback(self._cbStore)
        return dfr

    def _cbStore(self, data):
        flags = {}
        for id, dict in data.items():
            flags[id] = dict.get('FLAGS')

        return flags

class ProxyMessage(object):
    __implements__ = (imap4.IMessage,)

    def __init__(self, mId, uid, client):
        self.mId = mId
        self.uid = uid
        self.client = client
        self.msgData = None
        self.headers = None

    def getHeaders(self, negate=True, *names):
        if not len(names):
            if not negate:
                return []
            elif self.headers is not None:
                return self.headers
            else:
                dfr = self.client.fetchSpecific(imap4.MessageSet(self.mId),
                                                headerType = 'HEADER')
        else:
            if negate:
                negate = '.NOT'
            else:
                negate = ''
            if self.headers:
                if negate:
                    return imap4.HeaderList([(k,v) for k,v in self.headers
                                             if k.lower() not in names])
                else:
                    return imap4.HeaderList([(k,v) for k,v in self.headers
                                             if k.lower() in names])
            dfr = self.client.fetchSpecific(imap4.MessageSet(self.mId),
                                            headerType =
                                            'HEADER.FIELDS%s' % negate,
                                            headerArgs = names)
        dfr.addCallback(self._cbGetHeaders).addErrback(log.err)
        return dfr

    def _cbGetHeaders(self, data):
        data = data[self.mId] # If this fails, something is seriously broken
        print '_cbGetHeaders', data
        for d in data:
            if d[0].upper() == 'BODY' and d[1][0][:6].upper() == 'HEADER':
                data = d[2]
                break

        p = Parser()
        msg = p.parsestr(data, headersonly=True)

        hdr = imap4.HeaderList(msg.items())

        if d[1][0].upper() == 'HEADER': # i.e. all header fields
            self.headers = hdr

        return hdr

    def getFlags(self):
        dfr = self.client.fetchFlags(imap4.MessageSet(self.mId))
        dfr.addCallback(self._cbFetchData,'FLAGS')
        return dfr

    def _cbFetchData(self, data, type):
        return data[self.mId][type]

    def getInternalDate(self):
        dfr = self.client.fetchInternalDate(imap4.MessageSet(self.mId))
        dfr.addCallback(self._cbGetInternalDate)
        return dfr

    def _cbGetInternalDate(self, data):
        return imap4.imapToRfcDate(data[self.mId])

    def getBodyFile(self):
        dfr = self.client.fetchBody(imap4.MessageSet(self.mId))
        dfr.addCallback(self._cbFetchData,'RFC822.TEXT')

        return dfr

    def getSize(self):
        dfr = self.client.fetchSize(imap4.MessageSet(self.mId))
        dfr.addCallback(self._cbFetchData,'RFC822.SIZE')

        return dfr

    def getBodySize(self):
        if self.bodySize is None:
            dfr = self.fetchMimeData()
            dfr.addCallback(self._cbGetBodySize)
            return dfr
        else:
            return self.bodySize

    def _cbGetBodySize(self, spam):
        # fetchMimeData will fill it in
        return self.bodySize

    def getUID(self):
        return self.uid

    def getSubPart(self, part):
        return self.get_payload(part)

    def fetchMimeData(self):
        if self.msgData is not None:
            return self
        
        dfr = self.client.fetchMessage(imap4.MessageSet(self.mId))
        dfr.addCallback(self._cbFetchMimeData).addErrback(log.err)
        return dfr

    def _cbFetchMimeData(self, data):
        data = data[self.mId]['RFC822'] # If this fails, something is seriously broken
        print '_cbFetchMimeData', repr(data)

        p = Parser()
        self.msgData = p.parsestr(data)
        self.headers = imap4.HeaderList(self.msgData.items())
        lines = imap4.flattenBody(self.msgData).splitlines()
        self.bodySize = 2 * len(lines) + reduce(int.__add__,map(len, lines))
        
        print self.msgData
        return self

    def get_content_type(self):
        return self.msgData.get_content_type()

    def get_content_maintype(self):
        return self.msgData.get_content_maintype()

    def get_content_subtype(self):
        return self.msgData.get_content_subtype()

    def get_payload(self, index=None):
        if index is None:
            res = []
            for part in self.msgData.get_payload():
                res.append(ProxyMessagePart(self, part))
            return res
                          
        return ProxyMessagePart(self, self.msgData.get_payload(index))

    def get(self, key, default=None):
        return self.headers.get(key, default)

class ProxyMessagePart(ProxyMessage):
    def __init__(self, parent, msgData): 
        self.mId = parent.mId
        self.uid = parent.uid
        self.client = parent.client
        self.headers = imap4.HeaderList(msgData.items())
        self.msgData = msgData
       
